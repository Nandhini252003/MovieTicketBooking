package com.book.book_my_show.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.UsersRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.UsersResponseDto;
import com.book.book_my_show.service.implementation.UsersService;

@ExtendWith(MockitoExtension.class)
public class UsersServiceTest {

	@Mock
	private IUsersService usersService;

	@InjectMocks
	private UsersService usersServiceImpl;
	private UsersRequestDto usersRequestDto;
	private UsersResponseDto usersResponseDto;
	private List<UsersResponseDto> usersResponseDtos;

	@BeforeEach
	void setUp() {
		// Setup objects for each test case
		usersRequestDto = new UsersRequestDto();
		usersRequestDto.setAddressId(23);

		usersResponseDto = new UsersResponseDto();
		usersResponseDto.setUserId(1);
		usersResponseDto.setEmail("user@example.com");
//        usersResponseDto.setCity("New York");

		usersResponseDtos = Arrays.asList(usersResponseDto);
	}

	@Test
	void testGetUserByEmail() {
		ResponseStructure<UsersResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("User fetched successfully");
		responseStructure.setData(usersResponseDto);
		when(usersService.getUserByEmail("user@example.com"))
				.thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<UsersResponseDto>> response = usersService.getUserByEmail("user@example.com");

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("User fetched successfully", response.getBody().getMessage());
		assertEquals("user@example.com", response.getBody().getData().getEmail());
	}

	@Test
	void testGetAllUsers() {
		ResponseStructure<List<UsersResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("User fetched successfully");
		responseStructure.setData(usersResponseDtos);
		when(usersService.getAllUsers()).thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<List<UsersResponseDto>>> response = usersService.getAllUsers();

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("All users fetched successfully", response.getBody().getMessage());
		assertEquals(1, response.getBody().getData().size());
	}

	@Test
	void testGetUsersByCity() {
		ResponseStructure<List<UsersResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("User fetched successfully");
		responseStructure.setData(usersResponseDtos);
		when(usersService.getUsersByCity("New York"))
				.thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<List<UsersResponseDto>>> response = usersService.getUsersByCity("New York");

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("Users in city fetched successfully", response.getBody().getMessage());
		assertEquals(1, response.getBody().getData().size());
	}

	@Test
	void testAssignUserAddressByUserId() {
		ResponseStructure<UsersResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("User address assigned successfully");
		responseStructure.setData(usersResponseDto);
		when(usersService.assignUserAddressByUserId(1, usersRequestDto))
				.thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.CREATED));

		ResponseEntity<ResponseStructure<UsersResponseDto>> response = usersService.assignUserAddressByUserId(1,
				usersRequestDto);

		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("User address assigned successfully", response.getBody().getMessage());
		assertEquals(123, response.getBody().getData().getAddressId());
	}

	@Test
	void testGetUser() {
		ResponseStructure<UsersResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("User fetched successfully");
		responseStructure.setData(usersResponseDto);
		when(usersService.getUser(1)).thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<UsersResponseDto>> response = usersService.getUser(1);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("User fetched successfully", response.getBody().getMessage());
		assertEquals(1, response.getBody().getData().getUserId());
	}

	@Test
	void testUserDetailsByUserName() {
		ResponseStructure<UsersResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("User details fetched successfully");
		responseStructure.setData(usersResponseDto);
		when(usersService.userDetailsByUserName("username"))
				.thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<UsersResponseDto>> response = usersService.userDetailsByUserName("username");

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("User details fetched successfully", response.getBody().getMessage());
	}
}
