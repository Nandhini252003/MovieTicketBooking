package com.book.book_my_show.service;


import com.book.book_my_show.dao.IMovieDao;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.implementation.MovieService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import java.util.ArrayList;
import java.util.List;
 
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
 
public class MovieServiceTest {
 
    @Mock
    private IMovieDao iMovieDao;
 
    @InjectMocks
    private MovieService movieService;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    // Test getMovieByName
    @Test
    void testGetMovieByName_Success() {
        String movieName = "Inception";
        Movie movie = new Movie();
        movie.setMovieId(1);
        movie.setMovieName(movieName);
        movie.setTicketBasePrice(10);
 
        when(iMovieDao.getMovieByName(movieName)).thenReturn(movie);
 
        MovieResponseDto responseDto = movieService.getMovieByName(movieName);
 
        assertNotNull(responseDto);
        assertEquals(movie.getMovieId(), responseDto.getMovieId());
        assertEquals(movie.getMovieName(), responseDto.getMovieName());
        assertEquals(movie.getTicketBasePrice(), responseDto.getTicketBasePrice());
    }
 
    // Test getAllMovieDetails
    @Test
    void testGetAllMovieDetails_Success() {
        List<Movie> movies = new ArrayList<>();
        Movie movie1 = new Movie();
        movie1.setMovieId(1);
        movie1.setMovieName("Movie1");
        movie1.setTicketBasePrice(10);
        movies.add(movie1);
 
        Movie movie2 = new Movie();
        movie2.setMovieId(2);
        movie2.setMovieName("Movie2");
        movie2.setTicketBasePrice(15);
        movies.add(movie2);
 
        when(iMovieDao.getMovieDetails()).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getAllMovieDetails();
 
        assertEquals(HttpStatus.FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(2, response.getBody().getData().size());
        assertEquals("Movie1", response.getBody().getData().get(0).getMovieName());
    }
 
    // Test getMovieById
    @Test
    void testGetMovieById_Success() {
        int movieId = 1;
        Movie movie = new Movie();
        movie.setMovieId(movieId);
        movie.setMovieName("Inception");
        movie.setTicketBasePrice(10);
 
        when(iMovieDao.getMovieById(movieId)).thenReturn(movie);
 
        ResponseEntity<ResponseStructure<MovieResponseDto>> response = movieService.getMovieById(movieId);
 
        assertEquals(HttpStatus.FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(movieId, response.getBody().getData().getMovieId());
        assertEquals("Inception", response.getBody().getData().getMovieName());
    }
 
    // Test getMoviesByPrefix
    @Test
    void testGetMoviesByPrefix_Success() {
        String prefix = "In";
        List<Movie> movies = new ArrayList<>();
        Movie movie = new Movie();
        movie.setMovieId(1);
        movie.setMovieName("Inception");
        movie.setTicketBasePrice(10);
        movies.add(movie);
 
        when(iMovieDao.getMoviesByPrefix(prefix)).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getMoviesByPrefix(prefix);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("Inception", response.getBody().getData().get(0).getMovieName());
    }
 
    // Test getMoviesWithTicketPriceLessThan
    @Test
    void testGetMoviesWithTicketPriceLessThan_Success() {
        int price = 15;
        List<Movie> movies = new ArrayList<>();
        Movie movie1 = new Movie();
        movie1.setMovieId(1);
        movie1.setMovieName("Movie1");
        movie1.setTicketBasePrice(10);
        movies.add(movie1);
 
        when(iMovieDao.getMoviesWithTicketPriceLessThan(price)).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getMoviesWithTicketPriceLessThan(price);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("Movie1", response.getBody().getData().get(0).getMovieName());
    }
 
    // Test getMoviesWithTicketPriceLessThan No Content
    @Test
    void testGetMoviesWithTicketPriceLessThan_NoMovies() {
        int price = 10;
        List<Movie> movies = new ArrayList<>();
 
        when(iMovieDao.getMoviesWithTicketPriceLessThan(price)).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getMoviesWithTicketPriceLessThan(price);
 
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().getData().isEmpty());
    }
 
    // Test getMoviesBySubstring
    @Test
    void testGetMoviesBySubstring_Success() {
        String substring = "In";
        List<Movie> movies = new ArrayList<>();
        Movie movie = new Movie();
        movie.setMovieId(1);
        movie.setMovieName("Inception");
        movie.setTicketBasePrice(10);
        movies.add(movie);
 
        when(iMovieDao.findByMovieNameContaining(substring)).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getMoviesBySubstring(substring);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("Inception", response.getBody().getData().get(0).getMovieName());
    }
 
    // Test getMoviesByTicketPriceRange
    @Test
    void testGetMoviesByTicketPriceRange_Success() {
        int minPrice = 10;
        int maxPrice = 20;
        List<Movie> movies = new ArrayList<>();
        Movie movie = new Movie();
        movie.setMovieId(1);
        movie.setMovieName("Movie1");
        movie.setTicketBasePrice(15);
        movies.add(movie);
 
        when(iMovieDao.findMoviesByTicketPriceBetween(minPrice, maxPrice)).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getMoviesByTicketPriceRange(minPrice, maxPrice);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("Movie1", response.getBody().getData().get(0).getMovieName());
    }
 
    // Test getMoviesByTicketPriceRange No Content
    @Test
    void testGetMoviesByTicketPriceRange_NoMovies() {
        int minPrice = 10;
        int maxPrice = 20;
        List<Movie> movies = new ArrayList<>();
 
        when(iMovieDao.findMoviesByTicketPriceBetween(minPrice, maxPrice)).thenReturn(movies);
 
        ResponseEntity<ResponseStructure<List<MovieResponseDto>>> response = movieService.getMoviesByTicketPriceRange(minPrice, maxPrice);
 
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().getData().isEmpty());
    }
}
