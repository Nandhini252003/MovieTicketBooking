package com.book.book_my_show.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.PaymentRequestDto;
import com.book.book_my_show.model.responseDto.PaymentResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.implementation.PaymentService;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceTest {

	@Mock
	private IPaymentService paymentService;

	@InjectMocks
	private PaymentService paymentServiceImpl;
	private PaymentRequestDto paymentRequestDto;
	private PaymentResponseDto paymentResponseDto;
	private List<PaymentResponseDto> paymentResponseDtos;

	@BeforeEach
	void setUp() {
		// Setup objects for each test case
		paymentRequestDto = new PaymentRequestDto();
		paymentRequestDto.setAmount(100);
		paymentRequestDto.setUserId(4);

		paymentResponseDto = new PaymentResponseDto();
		paymentResponseDto.setPaymentId(1);
		paymentResponseDto.setAmount(100);
		paymentResponseDto.setPaymentStatus("Success");
		paymentResponseDtos = Arrays.asList(paymentResponseDto);
	}

	@Test
	void testGetPaymentById() {
		ResponseStructure<PaymentResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Payment fetched successfully");
		response.setData(paymentResponseDto);
		when(paymentService.getPaymentById(1)).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
		ResponseEntity<ResponseStructure<PaymentResponseDto>> responseStructure = paymentService.getPaymentById(1);
		assertEquals(HttpStatus.OK, responseStructure.getStatusCode());
		assertNotNull(responseStructure.getBody());
		assertEquals("Payment fetched successfully", responseStructure.getBody().getMessage());
		assertEquals(1, responseStructure.getBody().getData().getPaymentId());
	}

	@Test
	void testAddPayment() {
		ResponseStructure<PaymentResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Payment added successfully");
		responseStructure.setData(paymentResponseDto);

		when(paymentService.addPayment(paymentRequestDto))
				.thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.CREATED));

		ResponseEntity<ResponseStructure<PaymentResponseDto>> response = paymentService.addPayment(paymentRequestDto);

		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("Payment added successfully", response.getBody().getMessage());
		assertEquals(100, response.getBody().getData().getAmount());
	}

	@Test
	void testGetPaymentByStatus() {
		ResponseStructure<List<PaymentResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Payment fetched successfully");
		responseStructure.setData(paymentResponseDtos);
		when(paymentService.getPaymentByStatus("Success"))
				.thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> response = paymentService
				.getPaymentByStatus("Success");

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("Payments fetched successfully", response.getBody().getMessage());
		assertEquals(1, response.getBody().getData().size());
	}
	@Test
	void testGetPaymentsByUserId() {
		ResponseStructure<List<PaymentResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Payment fetched successfully");
		responseStructure.setData(paymentResponseDtos);
		when(paymentService.getPaymentsByUserId(1)).thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

		ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> response = paymentService.getPaymentsByUserId(1);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("Payments fetched for user successfully", response.getBody().getMessage());
		assertEquals(1, response.getBody().getData().size());
	}
}
