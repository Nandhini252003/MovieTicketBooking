package com.book.book_my_show.service;

import com.book.book_my_show.dao.ISeatDao;
import com.book.book_my_show.dao.ITierDao;
import com.book.book_my_show.model.entity.Seat;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.model.requestDto.SeatRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.SeatResponseDto;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.service.implementation.SeatService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
 
public class SeatServiceTest {
 
    @Mock
    private ISeatDao iSeatDao;
 
    @Mock
    private ITierDao iTierDao;
 
    @InjectMocks
    private SeatService seatService;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    @Test
    void testGetSeatById_Success() {
        int seatId = 1;
        Seat seat = new Seat();
        seat.setSeatId(seatId);
        seat.setSeatNumber("A1");
        when(iSeatDao.seatById(seatId)).thenReturn(seat);
 
        ResponseEntity<ResponseStructure<SeatResponseDto>> response = seatService.getSeatById(seatId);
        assertEquals(HttpStatus.FOUND, response.getStatusCode());
        assertEquals("Success", response.getBody().getMessage());
        assertEquals(seatId, response.getBody().getData().getSeatId());
        assertEquals("A1", response.getBody().getData().getSeatNumber());
    }
 
    @Test
    void testUpdateSeatBySeatIdTierId_Success() {
        int seatId = 1;
        int tierId = 1;
        SeatRequestDto seatRequestDto = new SeatRequestDto();
        seatRequestDto.setSeatNumber("B2");
 
        Seat seat = new Seat();
        seat.setSeatId(seatId);
        seat.setSeatNumber("A1");
        Tier tier = new Tier();
        tier.setTierId(tierId);
        seat.setTier(tier);
 
        when(iSeatDao.getSeatById(seatId)).thenReturn(seat);
        when(iTierDao.getTierById(tierId)).thenReturn(tier);
        when(iSeatDao.saveSeat(any(Seat.class))).thenReturn(seat);
 
        ResponseEntity<ResponseStructure<SeatResponseDto>> response = seatService.updateSeatBySeatIdTierId(seatId, tierId, seatRequestDto);
 
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("updated seat number successfully", response.getBody().getMessage());
        assertEquals("B2", response.getBody().getData().getSeatNumber());
    }
 
    @Test
    void testUpdateSeatBySeatIdTierId_SeatNotFound() {
        int seatId = 1;
        int tierId = 1;
        SeatRequestDto seatRequestDto = new SeatRequestDto();
        seatRequestDto.setSeatNumber("B2");
 
        when(iSeatDao.getSeatById(seatId)).thenReturn(null);
 
        DataNotFoundException exception = assertThrows(DataNotFoundException.class, () -> {
            seatService.updateSeatBySeatIdTierId(seatId, tierId, seatRequestDto);
        });
 
        assertEquals("no seat exists with the given id", exception.getMessage());
    }
 
    @Test
    void testAddSeatByTierId_Success() {
        int tierId = 1;
        SeatRequestDto seatRequestDto = new SeatRequestDto();
        seatRequestDto.setSeatNumber("C3");
 
        Tier tier = new Tier();
        tier.setTierId(tierId);
 
        when(iTierDao.findTierId(tierId)).thenReturn(true);
        when(iTierDao.findTierById(tierId)).thenReturn(tier);
        when(iSeatDao.saveSeat(any(Seat.class))).thenReturn(new Seat());
 
        ResponseEntity<ResponseStructure<SeatResponseDto>> response = seatService.AddSeatByTierId(seatRequestDto, tierId);
 
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Record created successfully", response.getBody().getMessage());
    }
 
    @Test
    void testAddSeatByTierId_TierNotFound() {
        int tierId = 1;
        SeatRequestDto seatRequestDto = new SeatRequestDto();
        seatRequestDto.setSeatNumber("C3");
 
        when(iTierDao.findTierId(tierId)).thenReturn(false);
 
        DataNotFoundException exception = assertThrows(DataNotFoundException.class, () -> {
            seatService.AddSeatByTierId(seatRequestDto, tierId);
        });
 
        assertEquals("Tier ID not found", exception.getMessage());
    }
 
 
    @Test
    void testGetSeatsBySeatNumber_NoContent() {
        String seatNumber = "B2";
 
        when(iSeatDao.findSeatsBySeatNumber(seatNumber)).thenReturn(List.of());
 
        ResponseEntity<ResponseStructure<List<SeatResponseDto>>> response = seatService.getSeatsBySeatNumber(seatNumber);
 
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertEquals("No seats found with seat number: B2", response.getBody().getMessage());
    }
}