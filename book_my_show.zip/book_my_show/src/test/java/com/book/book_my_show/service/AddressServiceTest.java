package com.book.book_my_show.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.repository.TheatreRepository;

import com.book.book_my_show.service.implementation.AddressService;

public class AddressServiceTest {
	
	@InjectMocks
    private AddressService addressService;

    @Mock
    private IAddressDao iAddressDao;
    
    @Mock
    private TheatreRepository theatreRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAddressesByCity() {
        // Arrange
        String city = "New York";
        List<Address> addressList = new ArrayList<>();
        Address address1 = new Address();
        address1.setAddressId(1);
        address1.setAddressLine("123 Main St");
        address1.setCity(city);
        address1.setState("NY");
        address1.setCountry("USA");

        Address address2 = new Address();
        address2.setAddressId(2);
        address2.setAddressLine("456 Elm St");
        address2.setCity(city);
        address2.setState("NY");
        address2.setCountry("USA");

        addressList.add(address1);
        addressList.add(address2);

        when(iAddressDao.getAddressesByCity(city)).thenReturn(addressList);

        // Act
        ResponseEntity<ResponseStructure<List<AddressResponseDto>>> responseEntity = addressService.getAddressesByCity(city);

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals(2, responseEntity.getBody().getData().size());
        assertEquals("123 Main St", responseEntity.getBody().getData().get(0).getAddressLine());
        assertEquals("New York", responseEntity.getBody().getData().get(0).getCity());
    }

    @Test
    void testGetAddressesByCity_NotFound() {
        // Arrange
        String city = "NonExistentCity";
        when(iAddressDao.getAddressesByCity(city)).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<ResponseStructure<List<AddressResponseDto>>> responseEntity = addressService.getAddressesByCity(city);

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertEquals(0, responseEntity.getBody().getData().size());
    }
    
    @Test
    void testGetAddressesByState() {
        // Arrange
        String state = "California";
        List<Address> addressList = new ArrayList<>();
        Address address1 = new Address();
        address1.setAddressId(1);
        address1.setAddressLine("123 Sunset Blvd");
        address1.setCity("Los Angeles");
        address1.setState(state);
        address1.setCountry("USA");

        Address address2 = new Address();
        address2.setAddressId(2);
        address2.setAddressLine("456 Oak St");
        address2.setCity("San Francisco");
        address2.setState(state);
        address2.setCountry("USA");

        addressList.add(address1);
        addressList.add(address2);

        when(iAddressDao.getAddressesByState(state)).thenReturn(addressList);

        // Act
        ResponseEntity<ResponseStructure<List<AddressResponseDto>>> responseEntity = addressService.getAddressesByState(state);

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals(2, responseEntity.getBody().getData().size());
        assertEquals("123 Sunset Blvd", responseEntity.getBody().getData().get(0).getAddressLine());
        assertEquals("California", responseEntity.getBody().getData().get(0).getState());
    }

    @Test
    void testGetAddressesByState_NotFound() {
        // Arrange
        String state = "NonExistentState";
        when(iAddressDao.getAddressesByState(state)).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<ResponseStructure<List<AddressResponseDto>>> responseEntity = addressService.getAddressesByState(state);

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertEquals(0, responseEntity.getBody().getData().size());
    }
    
    @Test
    void testGetAllAddress() {
        // Arrange
        List<Address> addressList = new ArrayList<>();
        
        Address address1 = new Address();
        address1.setAddressId(1);
        address1.setAddressLine("123 Sunset Blvd");
        address1.setCity("Los Angeles");
        address1.setState("California");
        address1.setCountry("USA");
        
        Address address2 = new Address();
        address2.setAddressId(2);
        address2.setAddressLine("456 Oak St");
        address2.setCity("San Francisco");
        address2.setState("California");
        address2.setCountry("USA");
        
        addressList.add(address1);
        addressList.add(address2);
        
        when(iAddressDao.getAllAddresses()).thenReturn(addressList);

        // Act
        ResponseEntity<ResponseStructure<List<AddressResponseDto>>> responseEntity = addressService.getAllAddress();

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals(2, responseEntity.getBody().getData().size());
        assertEquals("123 Sunset Blvd", responseEntity.getBody().getData().get(0).getAddressLine());
        assertEquals("California", responseEntity.getBody().getData().get(0).getState());
    }

    @Test
    void testGetAllAddress_EmptyList() {
        // Arrange
        when(iAddressDao.getAllAddresses()).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<ResponseStructure<List<AddressResponseDto>>> responseEntity = addressService.getAllAddress();

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertEquals(0, responseEntity.getBody().getData().size());
    }



    @Test
    void testGetAddressById() {
        // Arrange
        int addressId = 1;
        Address address = new Address();
        address.setAddressId(addressId);
        address.setAddressLine("123 Sunset Blvd");
        address.setCity("Los Angeles");
        address.setState("California");
        address.setCountry("USA");

        // Mock the behavior of the dao
        when(iAddressDao.getAddressById(addressId)).thenReturn(address);

        // Act
        ResponseEntity<ResponseStructure<AddressResponseDto>> responseEntity = addressService.getAddressById(addressId);

        // Assert
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals("123 Sunset Blvd", responseEntity.getBody().getData().getAddressLine());
        assertEquals("California", responseEntity.getBody().getData().getState());
        assertEquals("USA", responseEntity.getBody().getData().getCountry());
    }

  
    @Test
    void testAddNewAddress_Success() {
        // Arrange
        AddressRequestDto addressRequestDto = new AddressRequestDto();
        addressRequestDto.setAddressLine("123 Main St");
        addressRequestDto.setCity("CityName");
        addressRequestDto.setCountry("CountryName");
        addressRequestDto.setState("StateName");

        Address savedAddress = new Address();
        savedAddress.setAddressId(1);
        savedAddress.setAddressLine("123 Main St");
        savedAddress.setCity("CityName");
        savedAddress.setCountry("CountryName");
        savedAddress.setState("StateName");

        // Mock the behavior of the saveAddress method in the DAO
        when(iAddressDao.saveAddress(any(Address.class))).thenReturn(savedAddress);

        // Act
        ResponseEntity<ResponseStructure<AddressResponseDto>> responseEntity = addressService.AddNewAddress(addressRequestDto);

        // Assert
        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals(1, responseEntity.getBody().getData().getAddressId());
        assertEquals("123 Main St", responseEntity.getBody().getData().getAddressLine());
        assertEquals("CityName", responseEntity.getBody().getData().getCity());
        assertEquals("CountryName", responseEntity.getBody().getData().getCountry());
        assertEquals("StateName", responseEntity.getBody().getData().getState());
        assertEquals("Record Created Successfully.", responseEntity.getBody().getMessage());
        assertEquals(HttpStatus.CREATED.value(), responseEntity.getBody().getStatusCode());
    }
    
    
    @Test
    void testUpdateAddressById_Success() {
        // Arrange
        int addressId = 1;

        AddressRequestDto addressRequestDto = new AddressRequestDto();
        addressRequestDto.setAddressLine("456 New St");
        addressRequestDto.setCity("NewCity");
        addressRequestDto.setCountry("NewCountry");
        addressRequestDto.setState("NewState");

        Address existingAddress = new Address();
        existingAddress.setAddressId(addressId);
        existingAddress.setAddressLine("123 Old St");
        existingAddress.setCity("OldCity");
        existingAddress.setCountry("OldCountry");
        existingAddress.setState("OldState");

        Address updatedAddress = new Address();
        updatedAddress.setAddressId(addressId);
        updatedAddress.setAddressLine("456 New St");
        updatedAddress.setCity("NewCity");
        updatedAddress.setCountry("NewCountry");
        updatedAddress.setState("NewState");

        // Mock the behavior of the DAO methods
        when(iAddressDao.getaddressById(addressId)).thenReturn(existingAddress);
        when(iAddressDao.saveAddress(any(Address.class))).thenReturn(updatedAddress);

        // Act
        ResponseEntity<ResponseStructure<AddressResponseDto>> responseEntity = addressService.updateAddressById(addressRequestDto, addressId);

        // Assert
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals(addressId, responseEntity.getBody().getData().getAddressId());
        assertEquals("456 New St", responseEntity.getBody().getData().getAddressLine());
        assertEquals("NewCity", responseEntity.getBody().getData().getCity());
        assertEquals("NewCountry", responseEntity.getBody().getData().getCountry());
        assertEquals("NewState", responseEntity.getBody().getData().getState());
        assertEquals("Record Updated Successfully.", responseEntity.getBody().getMessage());
        assertEquals(HttpStatus.FOUND.value(), responseEntity.getBody().getStatusCode());
    }
    
    @Test
    void testGetMaxTheatreCapacityByCity_Success() {
        // Arrange
        String city = "City1";

        // Mocking the addresses and theatres
        Address address1 = new Address();
        address1.setAddressId(1);
        address1.setCity("City1");

        Address address2 = new Address();
        address2.setAddressId(2);
        address2.setCity("City1");

        Theatre theatre1 = new Theatre();
        theatre1.setTheatreId(1);
        theatre1.setTheatreName("Theatre1");
        theatre1.setCapacity(200);
        theatre1.setScreen("Premium");
        theatre1.setAddress(address1);

        Theatre theatre2 = new Theatre();
        theatre2.setTheatreId(2);
        theatre2.setTheatreName("Theatre2");
        theatre2.setCapacity(300);  // Max capacity
        theatre2.setScreen("basic");
        theatre2.setAddress(address2);

        // Mock the DAO methods
        when(iAddressDao.getAddressesByCity(city)).thenReturn(Arrays.asList(address1, address2));
        when(theatreRepository.findByAddress_AddressId(1)).thenReturn(Arrays.asList(theatre1));
        when(theatreRepository.findByAddress_AddressId(2)).thenReturn(Arrays.asList(theatre2));

        // Act
        ResponseEntity<ResponseStructure<TheatreResponseDto>> responseEntity = addressService.getMaxTheatreCapacityByCity(city);

        // Assert
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNotNull(responseEntity.getBody().getData());
        assertEquals("Theatre2", responseEntity.getBody().getData().getTheatreName());
        assertEquals(300, responseEntity.getBody().getData().getCapacity());
        assertEquals(2, responseEntity.getBody().getData().getAddress());
        assertEquals(2, responseEntity.getBody().getData().getTheatreId());
        assertEquals("basic", responseEntity.getBody().getData().getScreen());
        assertEquals("Max Capacity Theatre", responseEntity.getBody().getMessage());
    }

    // Test for scenario when no theatres are found for the given city
    @Test
    void testGetMaxTheatreCapacityByCity_NotFound() {
        // Arrange
        String city = "City2";

        // Mock the DAO methods to return an empty list
        when(iAddressDao.getAddressesByCity(city)).thenReturn(Arrays.asList());
        
        // Act
        ResponseEntity<ResponseStructure<TheatreResponseDto>> responseEntity = addressService.getMaxTheatreCapacityByCity(city);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertNull(responseEntity.getBody().getData());
        assertEquals("No theatres found for the given city", responseEntity.getBody().getMessage());
    }

  
}
