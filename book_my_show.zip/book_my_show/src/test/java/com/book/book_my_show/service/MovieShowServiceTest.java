package com.book.book_my_show.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.MovieShowRequestDto;
import com.book.book_my_show.model.responseDto.MovieShowResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.implementation.MovieShowService;

@ExtendWith(MockitoExtension.class)
public class MovieShowServiceTest {

    @Mock
    private IMovieShowService movieShowService;

    @InjectMocks
    private MovieShowService movieShowServiceImpl;
    private MovieShowRequestDto movieShowRequestDto;
    private MovieShowResponseDto movieShowResponseDto;
    private List<MovieShowResponseDto> movieShowResponseDtos;

    @BeforeEach
    void setUp() {
        // Setup objects for each test case
        movieShowRequestDto = new MovieShowRequestDto();
        movieShowRequestDto.setMovieId(1);
        movieShowRequestDto.setShowDateTime(null);
        movieShowRequestDto.setTheatreId(0);
        
//        movieShowRequestDto.setMovieName("Inception");
//        movieShowRequestDto.setCity("New York");
//        movieShowRequestDto.setScreenType("IMAX");

        movieShowResponseDto = new MovieShowResponseDto(1, 101, 201, "2025-01-18 15:00");

        movieShowResponseDtos = Arrays.asList(movieShowResponseDto);
    }

    @Test
    void testGetMovieShowByMovieName() {
        ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.FOUND.value());
        responseStructure.setMessage("Movie shows fetched successfully");
        responseStructure.setData(movieShowResponseDtos);
        when(movieShowService.getMovieShowByMovieName("Inception"))
                .thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

        ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> response = movieShowService.getMovieShowByMovieName("Inception");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Movie shows fetched successfully", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("Inception", response.getBody().getData().get(0).getMovieId());
    }

    @Test
    void testGetAllMovieShows() {
        ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.FOUND.value());
        responseStructure.setMessage("All movie shows fetched successfully");
        responseStructure.setData(movieShowResponseDtos);
        when(movieShowService.getAllMovieShows())
                .thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

        ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> response = movieShowService.getAllMovieShows();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("All movie shows fetched successfully", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().size());
    }

    @Test
    void testGetMovieShowsByMovieNameAndCity() {
        ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.FOUND.value());
        responseStructure.setMessage("Movie shows fetched by movie name and city");
        responseStructure.setData(movieShowResponseDtos);
        when(movieShowService.getMovieShowsByMovieNameAndCity("Inception", "New York"))
                .thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

        ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> response = movieShowService.getMovieShowsByMovieNameAndCity("Inception", "New York");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Movie shows fetched by movie name and city", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().size());
    }

    @Test
    void testSaveMovieShow() {
        ResponseStructure<MovieShowResponseDto> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.CREATED.value());
        responseStructure.setMessage("Movie show saved successfully");
        responseStructure.setData(movieShowResponseDto);
        when(movieShowService.saveMovieShow(movieShowRequestDto))
                .thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.CREATED));

        ResponseEntity<ResponseStructure<MovieShowResponseDto>> response = movieShowService.saveMovieShow(movieShowRequestDto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Movie show saved successfully", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().getShowId());
    }

    @Test
    void testGetMovieShowById() {
        ResponseStructure<MovieShowResponseDto> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.FOUND.value());
        responseStructure.setMessage("Movie show fetched by ID");
        responseStructure.setData(movieShowResponseDto);
        when(movieShowService.getMovieShowById(1))
                .thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

        ResponseEntity<ResponseStructure<MovieShowResponseDto>> response = movieShowService.getMovieShowById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Movie show fetched by ID", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().getShowId());
    }

    @Test
    void testFindShowByMovieNameScreenTypeCity() {
        ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.FOUND.value());
        responseStructure.setMessage("Show found by movie name, screen type, and city");
        responseStructure.setData(movieShowResponseDtos);
        when(movieShowService.findShowByMovieNameScreenTypeCity("Inception", "IMAX", "New York"))
                .thenReturn(new ResponseEntity<>(responseStructure, HttpStatus.OK));

        ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> response = movieShowService.findShowByMovieNameScreenTypeCity("Inception", "IMAX", "New York");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Show found by movie name, screen type, and city", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().size());
    }
}
