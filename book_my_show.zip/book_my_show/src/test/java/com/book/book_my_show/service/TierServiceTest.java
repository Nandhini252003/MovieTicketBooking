package com.book.book_my_show.service;




import com.book.book_my_show.dao.ITheatreDao;
import com.book.book_my_show.dao.ITierDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.TierRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TierResponseDto;
 
import com.book.book_my_show.service.implementation.TierService;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import java.util.List;
 
 
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
 
class TierServiceTest {
 
    @InjectMocks
    private TierService tierService;
 
    @Mock
    private ITierDao iTierDao;
 
    @Mock
    private ITheatreDao iTheatreDao;
 
    private TierRequestDto tierRequestDto;
    private Theatre theatre;
    private Tier tier;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        tierRequestDto = new TierRequestDto();
        tierRequestDto.setTierName("Gold");
        tierRequestDto.setTicketPriceMultiplier(1);
        tierRequestDto.setTheatreId(1);
 
        theatre = new Theatre();
        theatre.setTheatreId(1);
        theatre.setTheatreName("Theatre 1");
 
        tier = new Tier();
        tier.setTierId(1);
        tier.setTierName("Gold");
        tier.setTicketPriceMultiplier(1);
        tier.setTheatre(theatre);
    }
 
    @Test
    void testSaveTier() {
        when(iTheatreDao.findById(1)).thenReturn(theatre);
        when(iTierDao.saveTier(any(Tier.class))).thenReturn(tier);
 
        ResponseEntity<ResponseStructure<TierResponseDto>> response = tierService.saveTier(tierRequestDto);
 
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Tier created successfully", response.getBody().getMessage());
        assertEquals("Gold", response.getBody().getData().getTierName());
        verify(iTheatreDao, times(1)).findById(1);
        verify(iTierDao, times(1)).saveTier(any(Tier.class));
    }
 
    @Test
    void testSaveTier_TheatreNotFound() {
        when(iTheatreDao.findById(1)).thenReturn(null);
 
        assertThrows(DataNotFoundException.class, () -> tierService.saveTier(tierRequestDto));
 
        verify(iTheatreDao, times(1)).findById(1);
        verify(iTierDao, never()).saveTier(any(Tier.class));
    }
 
    @Test
    void testGetAllTiers() {
        when(iTierDao.findTiersByTheatreId(1)).thenReturn(List.of(tier));
 
        ResponseEntity<ResponseStructure<List<TierResponseDto>>> response = tierService.getAllTiers(1);
 
        assertEquals(HttpStatus.FOUND, response.getStatusCode());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("Gold", response.getBody().getData().get(0).getTierName());
    }
 
    @Test
    void testUpdateTier() {
        when(iTierDao.findTierById(1)).thenReturn(tier);
        when(iTheatreDao.findTheatreId(1)).thenReturn(true);
        when(iTheatreDao.findById(1)).thenReturn(theatre);
        when(iTierDao.saveTier(any(Tier.class))).thenReturn(tier);
 
        TierRequestDto updatedTierDto = new TierRequestDto();
        updatedTierDto.setTierName("Platinum");
        updatedTierDto.setTicketPriceMultiplier(2);
        updatedTierDto.setTheatreId(1);
 
        ResponseEntity<ResponseStructure<List<TierResponseDto>>> response = tierService.updateTier(updatedTierDto, 1, 1);
 
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Platinum", response.getBody().getData().get(0).getTierName());
        assertEquals(2.0, response.getBody().getData().get(0).getTicketPriceMultiplier());
    }
 
    @Test
    void testUpdateTier_TierNotFound() {
        when(iTierDao.findTierById(1)).thenReturn(null);
 
        TierRequestDto updatedTierDto = new TierRequestDto();
        updatedTierDto.setTierName("Platinum");
 
        assertThrows(DataNotFoundException.class, () -> tierService.updateTier(updatedTierDto, 1, 1));
 
        verify(iTierDao, times(1)).findTierById(1);
    }
 
    
}
