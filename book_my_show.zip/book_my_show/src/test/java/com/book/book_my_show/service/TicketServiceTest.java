package com.book.book_my_show.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.book.book_my_show.dao.IMovieShowDao;
import com.book.book_my_show.dao.ISeatDao;
import com.book.book_my_show.dao.ITicketDao;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.MovieShow;
import com.book.book_my_show.model.entity.Seat;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.entity.Ticket;
import com.book.book_my_show.model.requestDto.TicketRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.model.responseDto.TicketResponseDto;
import com.book.book_my_show.repository.TheatreRepository;
import com.book.book_my_show.service.implementation.TheatreService;
import com.book.book_my_show.service.implementation.TicketService;

public class TicketServiceTest {

	@Mock
	private ITicketDao iTicketDao;
	@Mock
	private IMovieShowDao iMovieShowDao;
	@Mock
	private ISeatDao iSeatDao;

	@InjectMocks
	private TicketService ticketService;

	@Mock
	private TheatreRepository theatreRepository;

	@InjectMocks
	private TheatreService theatreService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testAddTicket() {
		// Arrange: Set up the data
		TicketRequestDto ticketRequestDto = new TicketRequestDto();
		ticketRequestDto.setAmount(150);
		LocalDateTime purchaseDate = LocalDateTime.now();
	    ticketRequestDto.setPurchaseDate(purchaseDate);
		ticketRequestDto.setMovieShowId(1);
		ticketRequestDto.setSeatId(1);

		MovieShow movieShow = new MovieShow();// You can set specific details for the MovieShow entity
		movieShow.setShowId(2);
		Seat seat = new Seat(); // Set details for the Seat entity
		seat.setSeatId(8);
		Ticket savedTicket = new Ticket();
		savedTicket.setAmount(150);
		savedTicket.setPurchaseDate(purchaseDate);
		savedTicket.setMovieShow(movieShow);
		savedTicket.setSeat(seat);

		when(iMovieShowDao.movieShowById(ticketRequestDto.getMovieShowId())).thenReturn(movieShow);
		when(iSeatDao.seatById(ticketRequestDto.getSeatId())).thenReturn(seat);
		when(iTicketDao.addNewTicket(any(Ticket.class))).thenReturn(savedTicket);

		// Act: Call the service method
		ResponseEntity<ResponseStructure<TicketResponseDto>> responseEntity = ticketService.addTicket(ticketRequestDto);

		// Assert: Verify the results
		assertEquals(201, responseEntity.getStatusCode().value()); // HttpStatus.CREATED = 201
		assertNotNull(responseEntity.getBody().getData());
		assertEquals("Ticket added", responseEntity.getBody().getMessage());
	}

	@Test
	public void testGetTicketById() {
		// Arrange: Set up the data
		int ticketId = 1; // The ticket ID to search for

		// Create a MovieShow object
		MovieShow movieShow = new MovieShow();
		movieShow.setShowId(2); // Set the movie show ID

		// Create a Seat object
		Seat seat = new Seat();
		seat.setSeatId(8); // Set the seat ID

		// Create a Ticket object
		Ticket ticket = new Ticket();
		ticket.setTicketId(ticketId);
		ticket.setAmount(150);
		LocalDateTime purchaseDate = LocalDateTime.now();
	    ticket.setPurchaseDate(purchaseDate);
		ticket.setMovieShow(movieShow);
		ticket.setSeat(seat);

		// Mock the iTicketDao to return the ticket when getTicketById() is called
		when(iTicketDao.getTicketById(ticketId)).thenReturn(ticket);

		// Act: Call the service method
		ResponseEntity<ResponseStructure<TicketResponseDto>> responseEntity = ticketService.getTicketById(ticketId);

		// Assert: Verify the results
		// Step 1: Assert the HTTP status code is 302 (FOUND)
		assertEquals(302, responseEntity.getStatusCode().value()); // HttpStatus.FOUND = 302

		// Step 2: Assert that the response body is not null
		assertNotNull(responseEntity.getBody());
		assertNotNull(responseEntity.getBody().getData()); // The ticket data should not be null

		// Step 3: Assert that the ticket details are correct
		TicketResponseDto ticketResponseDto = responseEntity.getBody().getData();
		assertEquals(ticketId, ticketResponseDto.getTicketId());
		assertEquals(150, ticketResponseDto.getAmount());
		assertEquals("2025-01-01", ticketResponseDto.getPurchaseDate());
		assertEquals(8, ticketResponseDto.getSeatId());
		assertEquals(2, ticketResponseDto.getMovieShowId());
	}

	@Test
	public void testGetTheatreWithMaxTicketsSold() {
		// Arrange: Set up the data

		// Create Theatre objects
		Theatre theatre1 = new Theatre();
		theatre1.setTheatreId(1);
		theatre1.setTheatreName("Theatre 1");
		theatre1.setCapacity(200);
		theatre1.setScreen("Screen 1");
		theatre1.setAddress(new Address());

		Theatre theatre2 = new Theatre();
		theatre2.setTheatreId(2);
		theatre2.setTheatreName("Theatre 2");
		theatre2.setCapacity(300);
		theatre2.setScreen("Screen 2");
		theatre2.setAddress(new Address());

		// Mock list of theatres
		List<Theatre> theatres = Arrays.asList(theatre1, theatre2);

		// Mock the count of tickets for each theatre
		when(theatreRepository.findAll()).thenReturn(theatres);
		when(iTicketDao.countTicketsByTheatreId(1)).thenReturn(100); // Theatre 1 has 100 tickets sold
		when(iTicketDao.countTicketsByTheatreId(2)).thenReturn(150); // Theatre 2 has 150 tickets sold

		// Act: Call the service method
		ResponseEntity<ResponseStructure<TheatreResponseDto>> responseEntity = ticketService
				.getTheatreWithMaxTicketsSold();

		// Assert: Verify the results
		assertEquals(HttpStatus.FOUND.value(), responseEntity.getStatusCode().value()); // HttpStatus.FOUND = 302
		assertEquals("theatre details with maximun number of tickets sold", responseEntity.getBody().getMessage());

		// Check that the response contains the correct theatre data
		TheatreResponseDto theatreResponseDto = responseEntity.getBody().getData();
		assertEquals(2, theatreResponseDto.getTheatreId()); // Theatre with the maximum tickets sold is Theatre 2
		assertEquals("Theatre 2", theatreResponseDto.getTheatreName());
		assertEquals(300, theatreResponseDto.getCapacity());
		assertEquals("Screen 2", theatreResponseDto.getScreen());
	}

	@Test
	public void testGetTheatreWithMaxTicketsSold_NoTheatres() {
		// Arrange: Set up the data when no theatres are found
		when(theatreRepository.findAll()).thenReturn(Arrays.asList());

		// Act: Call the service method
		ResponseEntity<ResponseStructure<TheatreResponseDto>> responseEntity = ticketService
				.getTheatreWithMaxTicketsSold();

		// Assert: Verify the results
		assertEquals(HttpStatus.NOT_FOUND.value(), responseEntity.getStatusCode().value()); // HttpStatus.NOT_FOUND =
																							// 404
		assertEquals("No theatres found or no tickets sold", responseEntity.getBody().getMessage());
	}

}
