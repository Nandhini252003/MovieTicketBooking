package com.book.book_my_show.service;

import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.dao.ITheatreDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.TheatreRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.service.implementation.TheatreService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TheatreServiceTest {

    @InjectMocks
    private TheatreService theatreService;

    @Mock
    private ITheatreDao iTheatreDao;

    @Mock
    private IAddressDao iAddressDao;

    private TheatreRequestDto theatreRequestDto;
    private Theatre theatre;
    private Address address;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        address = new Address();
        address.setAddressId(1);
        address.setCity("City");
        address.setCountry("Country");
        address.setState("State");
        address.setAddressLine("Street");

        theatreRequestDto = new TheatreRequestDto();
        theatreRequestDto.setTheatreName("Theatre1");
        theatreRequestDto.setCapacity(200);
        theatreRequestDto.setScreen("IMAX");
        theatreRequestDto.setAddressId(1);

        theatre = new Theatre();
        theatre.setTheatreId(1);
        theatre.setTheatreName("Theatre1");
        theatre.setCapacity(200);
        theatre.setScreen("IMAX");
        theatre.setAddress(address);
    }

    @Test
    void testSaveTheatre() {
        // Mocking the DAO calls
        when(iAddressDao.getaddressById(1)).thenReturn(address);
        when(iTheatreDao.saveTheatre(any(Theatre.class))).thenReturn(theatre);

        // Call the method under test
        ResponseEntity<ResponseStructure<TheatreResponseDto>> response = theatreService.saveTheatre(theatreRequestDto);

        // Assertions
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody().getData());
        assertEquals("Theatre1", response.getBody().getData().getTheatreName());
        assertEquals("IMAX", response.getBody().getData().getScreen());
    }

    @Test
    void testSaveTheatre_AddressNotFound() {
        when(iAddressDao.getaddressById(1)).thenReturn(null);

        assertThrows(DataNotFoundException.class, () -> theatreService.saveTheatre(theatreRequestDto));
    }

    @Test
    void testGetAllTheatres() {
        // Mocking DAO
        when(iTheatreDao.getAllTheatres()).thenReturn(Arrays.asList(theatre));

        // Call the method under test
        ResponseStructure<List<TheatreResponseDto>> response = theatreService.getAllTheatres();

        // Assertions
        assertEquals(200, response.getStatusCode());
        assertEquals("Fetched all theatre details successfully", response.getMessage());
        assertEquals(1, response.getData().size());
        assertEquals("Theatre1", response.getData().get(0).getTheatreName());
    }

    @Test
    void testGetTheatresByCountry() {
        // Mocking DAO
        when(iTheatreDao.findByAddressCountry("Country")).thenReturn(Arrays.asList(theatre));

        // Call the method under test
        ResponseEntity<ResponseStructure<List<Theatre>>> response = theatreService.getTheatresByCountry("Country");

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Theatres found.", response.getBody().getMessage());
        assertEquals(1, response.getBody().getData().size());
    }

    @Test
    void testGetTheatresByCountry_NotFound() {
        when(iTheatreDao.findByAddressCountry("Country")).thenReturn(Arrays.asList());

        ResponseEntity<ResponseStructure<List<Theatre>>> response = theatreService.getTheatresByCountry("Country");

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("No theatres found for the given country.", response.getBody().getMessage());
    }

    @Test
    void testFindById() {
        // Mocking DAO
        when(iTheatreDao.findById(1)).thenReturn(theatre);

        // Call the method under test
        ResponseEntity<ResponseStructure<Theatre>> response = theatreService.findById(1);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Theatre details fetched successfully", response.getBody().getMessage());
        assertEquals("Theatre1", response.getBody().getData().getTheatreName());
    }

    @Test
    void testGetTheatreAddress() {
        // Mocking DAO
        when(iTheatreDao.findById(1)).thenReturn(theatre);
        when(iAddressDao.getaddressById(1)).thenReturn(address);

        // Call the method under test
        ResponseEntity<ResponseStructure<AddressResponseDto>> response = theatreService.getTheatreAddress(1);

        // Assertions
        assertEquals(HttpStatus.FOUND, response.getStatusCode());
        assertEquals("Theatre address found successfully", response.getBody().getMessage());
        assertEquals("Street", response.getBody().getData().getAddressLine());
    }

    @Test
    void testGetTheatreAddress_ThrowsException() {
        // Mocking DAO
        when(iTheatreDao.findById(1)).thenReturn(theatre);
        when(iAddressDao.getaddressById(1)).thenReturn(null);

        assertThrows(DataNotFoundException.class, () -> theatreService.getTheatreAddress(1));
    }

    @Test
    void testGetTheatreWithMaxCapacity() {
        // Mocking DAO
        when(iTheatreDao.getTheatreWithMaxCapacity()).thenReturn(java.util.Optional.of(theatre));

        // Call the method under test
        ResponseEntity<ResponseStructure<Theatre>> response = theatreService.getTheatreWithMaxCapacity();

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Theatre with maximum capacity found", response.getBody().getMessage());
    }

    @Test
    void testGetTheatreWithMaxCapacity_NotFound() {
        when(iTheatreDao.getTheatreWithMaxCapacity()).thenReturn(java.util.Optional.empty());

        ResponseEntity<ResponseStructure<Theatre>> response = theatreService.getTheatreWithMaxCapacity();

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("No theatres available", response.getBody().getMessage());
    }

    @Test
    void testGetTheatresInAlphabeticalOrder() {
        // Mocking DAO
        when(iTheatreDao.findTheatresInAlphabeticalOrder()).thenReturn(Arrays.asList("Theatre1", "Theatre2"));

        // Call the method under test
        ResponseEntity<ResponseStructure<List<String>>> response = theatreService.getTheatresInAlphabeticalOrder();

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Theatre names listed in alphabetical order", response.getBody().getMessage());
        assertEquals(2, response.getBody().getData().size());
    }

    @Test
    void testGetTheatresByCapacityRange() {
        // Mocking DAO
        when(iTheatreDao.getTheatresByCapacityRange(100, 300)).thenReturn(Arrays.asList(theatre));

        // Call the method under test
        ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> response = theatreService.getTheatresByCapacityRange(100, 300);

        // Assertions
//        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Theatres found in this capacity range", response.getBody().getMessage());
    }

    @Test
    void testGetTheatresByScreenType() {
        // Mocking DAO
        when(iTheatreDao.getTheatresByScreenType("IMAX")).thenReturn(Arrays.asList(theatre));

        // Call the method under test
        ResponseStructure<List<TheatreResponseDto>> response = theatreService.getTheatresByScreenType("IMAX");

        // Assertions
//        assertEquals(HttpStatus.OK, response.getStatusCode()); 
        assertEquals("Theatres found with the screen type: IMAX", response.getMessage());
    }
}

