package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class MovieShowRequestDto {

    @NotNull(message = "Movie ID cannot be null")
    @Min(value = 1, message = "Movie ID should be greater than or equal to 1")
    private int movieId;

    @NotNull(message = "Theatre ID cannot be null")
    @Min(value = 1, message = "Theatre ID should be greater than or equal to 1")
    private int theatreId;

    @NotEmpty(message = "Show Date and Time cannot be empty")
    @FutureOrPresent(message = "Show Date and Time should be in the future or present")
    private String showDateTime; // You can use @DateTimeFormat if you want to validate specific date format

    // Getters and Setters
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public int getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(int theatreId) {
        this.theatreId = theatreId;
    }

    public String getShowDateTime() {
        return showDateTime;
    }

    public void setShowDateTime(String showDateTime) {
        this.showDateTime = showDateTime;
    }
}
