package com.book.book_my_show.dao;

import java.util.List;
import java.util.Optional;

import com.book.book_my_show.model.entity.Movie;

public interface IMovieDao {
	Movie getMovieByName(String movieName);

	List<Movie> getMovieDetails();
	Movie getMovieByMovieId(int movieId);
	Movie saveMovie(Movie movie);
	Movie getMovieById(int movieId);
	public List<Movie> getMoviesByPrefix(String prefix);
	 public List<Movie> getMoviesWithTicketPriceLessThan(int price);
	 public List<Movie> findByMovieNameContaining(String name);
	 public List<Movie> findMoviesByTicketPriceBetween(int minPrice, int maxPrice);

}
