package com.book.book_my_show.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.book.book_my_show.model.entity.Offer;

public interface OfferRepository extends JpaRepository<Offer, Integer> {

}
