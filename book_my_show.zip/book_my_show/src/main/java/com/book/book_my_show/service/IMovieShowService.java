package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.MovieShowRequestDto;
import com.book.book_my_show.model.responseDto.MovieShowResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;


public interface IMovieShowService {

	ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowByMovieName(String movieName);

	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getAllMovieShows();
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowsByMovieNameAndCity(String movieName, String city);
	public ResponseEntity<ResponseStructure<MovieShowResponseDto>> saveMovieShow(MovieShowRequestDto movieShowRequestDto);

	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowsByTheatreName(String moviename);

	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> findShowByMovieNameScreenTypeCity(
			String movieName, String screenType, String city);

	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> searchMovieShows(String movie_name,
			String screen, String city);
	public ResponseEntity<ResponseStructure<MovieShowResponseDto>> getMovieShowById(int movieShowId);
}
