package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.TierRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TierResponseDto;

public interface ITierService {
	ResponseEntity<ResponseStructure<List<TierResponseDto>>> getAllTiers(int id);
	public ResponseEntity<ResponseStructure<TierResponseDto>> saveTier(TierRequestDto tierRequestDto);
	ResponseEntity<ResponseStructure<List<TierResponseDto>>> updateTier(TierRequestDto tier, int theatre_id,
			int tier_id);
}
