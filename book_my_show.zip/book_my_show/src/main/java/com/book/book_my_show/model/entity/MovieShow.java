package com.book.book_my_show.model.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "movie_show")
public class MovieShow {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "show_id")
	private int showId;
	@ManyToOne
	@JoinColumn(name = "movie_id")
	@JsonManagedReference
	@NotNull(message = "Movie ID cannot be null")
	@Min(value = 1, message = "Movie ID should be greater than or equal to 1")
	private Movie movie;

	@ManyToOne
	@JoinColumn(name = "theatre_id")
	@JsonManagedReference
	@NotNull(message = "Theatre ID cannot be null")
	@Min(value = 1, message = "Theatre ID should be greater than or equal to 1")
	private Theatre theatre;

	@Column(name = "show_datetime")
	@NotEmpty(message = "Show Date and Time cannot be empty")
	@FutureOrPresent(message = "Show Date and Time should be in the future or present")
	private String showDateTime;

	public List<Offer> getOffers() {
		return offers;
	}

	public void setOffers(List<Offer> offers) {
		this.offers = offers;
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	@JsonIgnore
	@OneToMany(mappedBy = "movieShow")
	@JsonBackReference
	private List<Offer> offers;
	@OneToMany(mappedBy = "movieShow")
	@JsonBackReference
	private List<Ticket> tickets;

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	public String getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(String showDateTime) {
		this.showDateTime = showDateTime;
	}

	@Override
	public String toString() {
		return "MovieShow [showId=" + showId + ", movieId=" + (movie != null ? movie.getMovieId() : "null")

				+ ", theatreId=" + (theatre != null ? theatre.getTheatreId() : "null") + ", showDateTime="
				+ showDateTime + ", offersCount=" + (offers != null ? offers.size() : "null")

				+ ", ticketsCount=" + (tickets != null ? tickets.size() : "null") + "]";
	}

}
