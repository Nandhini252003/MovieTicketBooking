package com.book.book_my_show.model.responseDto;

public class MovieShowResponseDto {
	private int showId;
	private int movieId;
	private int theatreId;
	private String showDateTime;

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public int getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}

	public String getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(String showDateTime) {
		this.showDateTime = showDateTime;
	}

	public MovieShowResponseDto(int showId, int movieId, int theatreId, String showDateTime) {
		super();
		this.showId = showId;
		this.movieId = movieId;
		this.theatreId = theatreId;
		this.showDateTime = showDateTime;
	}

	public MovieShowResponseDto() {
	}
}
