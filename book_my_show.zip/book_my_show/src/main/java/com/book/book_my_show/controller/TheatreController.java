package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.requestDto.TheatreRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.service.ITheatreService;
import com.book.book_my_show.service.implementation.TicketService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/theatres")
@Tag(name = "Movie-Ticket-booking Insights API", description = "API endpoints that puts out Insights of the movie-ticket-booking")
public class TheatreController {

	@Autowired
	private ITheatreService iTheatreService;

	@Autowired
	private TicketService ticketService;

	@GetMapping("/theatreName/{theatreName}")
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> theatreDetailsByName(
			@PathVariable String theatreName) {
		return iTheatreService.theatreDetailsByName(theatreName);
	}

	@GetMapping("/country/{country}")
	public ResponseEntity<ResponseStructure<List<Theatre>>> getTheatresByCountry(@PathVariable String country) {
		return iTheatreService.getTheatresByCountry(country);
	}

	@PostMapping
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> addNewTheatre(
			@RequestBody @Valid TheatreRequestDto theatreRequestDto, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			ResponseStructure<TheatreResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
		}

		return iTheatreService.saveTheatre(theatreRequestDto);
	}

	@GetMapping("/city/{city}")
	public ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getTheatreByCity(@PathVariable String city) {
		return iTheatreService.getTheatreByCity(city);
	}

	@PutMapping("/{theatreId}")
	public ResponseEntity<ResponseStructure<AddressResponseDto>> updateTheatre(@PathVariable int theatreId,
			@RequestBody AddressRequestDto addressRequestDto) {
		return iTheatreService.updateTheatre(theatreId, addressRequestDto);
	}

	@GetMapping("/getAll")
	public ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getAllTheatres() {
		return ResponseEntity.ok(iTheatreService.getAllTheatres());
	}

	@GetMapping("/max-capacity")
	public ResponseEntity<ResponseStructure<Theatre>> getTheatreWithMaxCapacity() {
		return iTheatreService.getTheatreWithMaxCapacity();
	}

	@GetMapping("/alphabetical-order")
	public ResponseEntity<ResponseStructure<List<String>>> getTheatresInAlphabeticalOrder() {
		return iTheatreService.getTheatresInAlphabeticalOrder();
	}

	@GetMapping("/capacity")
	public ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getTheatresByCapacityRange(
			@RequestParam("minCapacity") int minCapacity, @RequestParam("maxCapacity") int maxCapacity) {
		return iTheatreService.getTheatresByCapacityRange(minCapacity, maxCapacity);
	}

	@GetMapping("/{screenType}")
	public ResponseStructure<List<TheatreResponseDto>> getTheatresByScreen(@PathVariable String screenType) {
		return iTheatreService.getTheatresByScreenType(screenType);
	}

	@GetMapping("/address/{theatreId}")
	public ResponseEntity<ResponseStructure<AddressResponseDto>> getTheatreAddress(@PathVariable int theatreId) {
		return iTheatreService.getTheatreAddress(theatreId);
	}

	@GetMapping("/maxTickets")
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> getTheatreWithMaxTicketsSold() {
		return ticketService.getTheatreWithMaxTicketsSold();
	}
}