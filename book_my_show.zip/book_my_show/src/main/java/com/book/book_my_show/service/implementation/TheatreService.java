package com.book.book_my_show.service.implementation;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.dao.ITheatreDao;
import com.book.book_my_show.exception.DataAlreadyExistsException;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.requestDto.TheatreRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.repository.AddressRepository;
import com.book.book_my_show.service.ITheatreService;

@Service
public class TheatreService implements ITheatreService {
	@Autowired
	private ITheatreDao iTheatreDao;
	
	@Autowired
	private IAddressDao iAddressDao;
	@Autowired
	private AddressRepository addressRepository;

	@Override
	public ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getTheatreByCity(String city) {
		
		        List<Theatre> theatre = iTheatreDao.getTheatreByCity(city);
				        List<TheatreResponseDto> theatreResponseDtos = theatre.stream()
		        		.map(theatreResponseDto -> new TheatreResponseDto (
		        				theatreResponseDto.getTheatreId(),
		        				theatreResponseDto.getAddress().getAddressId(),
		        				theatreResponseDto.getTheatreName(),
		        				theatreResponseDto.getCapacity(),
		        				theatreResponseDto.getScreen()
		        				))
		        		.collect(Collectors.toList());

		        if (!theatreResponseDtos.isEmpty()) {
	            ResponseStructure<List<TheatreResponseDto>> response = new ResponseStructure<>();
		            response.setData(theatreResponseDtos);
		            response.setMessage("Theatre found");
		            response.setStatusCode(HttpStatus.FOUND.value());
		            return new ResponseEntity<>(response, HttpStatus.FOUND);
	        } else {
		            throw new DataNotFoundException("Theatre doesn't Exist for this city: " + city);
	      }
	    }

	@Override
	public ResponseEntity<ResponseStructure<AddressResponseDto>> updateTheatre(int theatreId, AddressRequestDto addressRequestDto) {
	    Theatre theatre = iTheatreDao.getTheatreById(theatreId);
	    if (theatre == null) {
	        throw new DataNotFoundException("Theatre not found for ID: " + theatreId);
	    }
	    System.out.println("id:"+theatre.getAddress().getAddressId());

	    Address address = addressRepository.findById(theatre.getAddress().getAddressId()).get();
	    if (address == null) {
	        throw new DataNotFoundException("Address not found for the given ID");
	    }

	    address.setCity(addressRequestDto.getCity());
	    address.setCountry(addressRequestDto.getCountry());
	    address.setState(addressRequestDto.getState());
	    address.setAddressLine(addressRequestDto.getAddressLine());
	    Address a = addressRepository.save(address);
	    theatre.setAddress(a);
    
	    Theatre updatedTheatre = iTheatreDao.saveTheatre(theatre);

	    AddressResponseDto addressResponseDto = new AddressResponseDto();
	    addressResponseDto.setAddressId(updatedTheatre.getAddress().getAddressId());
	    addressResponseDto.setCity(updatedTheatre.getAddress().getCity());
	    addressResponseDto.setCountry(updatedTheatre.getAddress().getCountry());
	    addressResponseDto.setState(updatedTheatre.getAddress().getState());
	    addressResponseDto.setAddressLine(updatedTheatre.getAddress().getAddressLine());

	    ResponseStructure<AddressResponseDto> response = new ResponseStructure<>();
	    response.setStatusCode(HttpStatus.CREATED.value());
	    response.setMessage("Success");
	    response.setData(addressResponseDto);

	    return new ResponseEntity<>(response, HttpStatus.CREATED);
	}


	@Override
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> theatreDetailsByName(String theatreName) {
		Theatre theatre = iTheatreDao.theatreDetailsByName(theatreName);
		TheatreResponseDto theatreResponseDto = new TheatreResponseDto();
		theatreResponseDto.setTheatreId(theatre.getTheatreId());
		theatreResponseDto.setCapacity(theatre.getCapacity());
		theatreResponseDto.setScreen(theatre.getScreen());
		theatreResponseDto.setTheatreName(theatre.getTheatreName());
		theatreResponseDto.setAddressId(theatre.getAddress().getAddressId());

		ResponseStructure<TheatreResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Theatre Found");
		response.setData(theatreResponseDto);
		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}
	
	public ResponseStructure<List<TheatreResponseDto>> getAllTheatres() {
		List<Theatre> theatres = iTheatreDao.getAllTheatres();
		List<TheatreResponseDto> theatreResponseDtos = theatres.stream()
				.map(theatre -> new TheatreResponseDto(theatre.getTheatreId(), theatre.getAddress().getAddressId(),
						theatre.getTheatreName(), theatre.getCapacity(), theatre.getScreen()))
				.collect(Collectors.toList());
		ResponseStructure<List<TheatreResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(200);
		responseStructure.setMessage("Fetched all theatre details successfully");
		responseStructure.setData(theatreResponseDtos);
		return responseStructure;
	}

	public ResponseEntity<ResponseStructure<TheatreResponseDto>> saveTheatre(TheatreRequestDto theatreRequestDto) {
		Address address = iAddressDao.getaddressById(theatreRequestDto.getAddressId());

		if (address == null) {
			throw new DataNotFoundException("Address not found with the given ID");
		}
		
		Theatre theatre = new Theatre();

		theatre.setTheatreName(theatreRequestDto.getTheatreName());
		theatre.setCapacity(theatreRequestDto.getCapacity());
		theatre.setScreen(theatreRequestDto.getScreen());
		theatre.setAddress(address);

		Theatre savedTheatre = iTheatreDao.saveTheatre(theatre);
		TheatreResponseDto savedTheatreResponseDto = new TheatreResponseDto();

		savedTheatreResponseDto.setAddressId(savedTheatre.getAddress().getAddressId());
		savedTheatreResponseDto.setTheatreId(savedTheatre.getTheatreId());
		savedTheatreResponseDto.setScreen(savedTheatre.getScreen());
		savedTheatreResponseDto.setCapacity(savedTheatre.getCapacity());
		savedTheatreResponseDto.setTheatreName(savedTheatre.getTheatreName());
		ResponseStructure<TheatreResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("Theatre added successfully");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(savedTheatreResponseDto);
		return new ResponseEntity<>(responseStructure, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<Theatre>>> getTheatresByCountry(String country) {
		List<Theatre> theatres = iTheatreDao.findByAddressCountry(country);
		ResponseStructure<List<Theatre>> responseStructure = new ResponseStructure<>();

		if (theatres.isEmpty()) {
			responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
			responseStructure.setMessage("No theatres found for the given country.");
			responseStructure.setData(null);
			return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
		}

		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Theatres found.");
		responseStructure.setData(theatres);
		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ResponseStructure<Theatre>> findById(int theatreId) {
		Theatre theatre = iTheatreDao.findById(theatreId);
		ResponseStructure<Theatre> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value()); // Set HTTP Status Code
		responseStructure.setMessage("Theatre details fetched successfully");
		responseStructure.setData(theatre);
		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ResponseStructure<AddressResponseDto>> getTheatreAddress(int theatreId) {
		Theatre theatre = iTheatreDao.findById(theatreId);
		int addressId = theatre.getAddress().getAddressId();
		Address address = iAddressDao.getaddressById(addressId);
		if (address == null) {
			throw new DataNotFoundException("address doesnot exists for the given theatre id:" + theatreId);
		}

		AddressResponseDto savedAddressResponseDto = new AddressResponseDto();
		savedAddressResponseDto.setAddressId(address.getAddressId());
		savedAddressResponseDto.setCountry(address.getCountry());
		savedAddressResponseDto.setCity(address.getCity());
		savedAddressResponseDto.setState(address.getState());
		savedAddressResponseDto.setAddressLine(address.getAddressLine());

		ResponseStructure<AddressResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("Theatre address found successfully");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(savedAddressResponseDto);
		return new ResponseEntity<>(responseStructure, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<Theatre>> getTheatreWithMaxCapacity() {
		Theatre theatre = iTheatreDao.getTheatreWithMaxCapacity().orElse(null);

		ResponseStructure<Theatre> responseStructure = new ResponseStructure<>();

		if (theatre != null) {
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setMessage("Theatre with maximum capacity found");
			responseStructure.setData(theatre);
			return new ResponseEntity<>(responseStructure, HttpStatus.OK);
		} else {
			responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
			responseStructure.setMessage("No theatres available");
			responseStructure.setData(null);
			return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public ResponseEntity<ResponseStructure<List<String>>> getTheatresInAlphabeticalOrder() {
		List<String> theatreNames = iTheatreDao.findTheatresInAlphabeticalOrder();

		ResponseStructure<List<String>> responseStructure = new ResponseStructure<>();

		if (theatreNames != null && !theatreNames.isEmpty()) {
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setMessage("Theatre names listed in alphabetical order");
			responseStructure.setData(theatreNames);
			return new ResponseEntity<>(responseStructure, HttpStatus.OK);
		} else {
			responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
			responseStructure.setMessage("No theatres found");
			responseStructure.setData(null);
			return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getTheatresByCapacityRange(int minCapacity,
			int maxCapacity) {

		List<Theatre> theatres = iTheatreDao.getTheatresByCapacityRange(minCapacity, maxCapacity);

		List<TheatreResponseDto> theatreResponseDtos = theatres.stream().map(data -> {
			TheatreResponseDto dto = new TheatreResponseDto();
			dto.setAddressId(data.getAddress().getAddressId());
			dto.setTheatreId(data.getTheatreId());
			dto.setTheatreName(data.getTheatreName());
			dto.setScreen(data.getScreen());
			dto.setCapacity(data.getCapacity());

			return dto;

		}).collect(Collectors.toList());

		ResponseStructure<List<TheatreResponseDto>> responseStructure = new ResponseStructure<>();

		if (theatreResponseDtos.isEmpty()) {
			responseStructure.setStatusCode(HttpStatus.NO_CONTENT.value());
			responseStructure.setMessage("No theatres found in this capacity range");
			responseStructure.setData(theatreResponseDtos);
		} else {
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setMessage("Theatres found in this capacity range");
			responseStructure.setData(theatreResponseDtos);
		}
		return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseStructure<List<TheatreResponseDto>> getTheatresByScreenType(String screenType) {
		List<Theatre> theatres = iTheatreDao.getTheatresByScreenType(screenType);

		ResponseStructure<List<TheatreResponseDto>> responseStructure = new ResponseStructure<>();

		if (theatres.isEmpty()) {
			responseStructure.setStatusCode(HttpStatus.NO_CONTENT.value());
			responseStructure.setMessage("No theatres found with the screen type: " + screenType);
			responseStructure.setData(theatres.stream()
					.map(theatre -> new TheatreResponseDto(theatre.getTheatreId(), theatre.getAddress().getAddressId(),
							theatre.getTheatreName(), theatre.getCapacity(), theatre.getScreen()))
					.collect(Collectors.toList()));
		} else {

			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setMessage("Theatres found with the screen type: " + screenType);
			responseStructure.setData(theatres.stream()
					.map(theatre -> new TheatreResponseDto(theatre.getTheatreId(), theatre.getAddress().getAddressId(),
							theatre.getTheatreName(), theatre.getCapacity(), theatre.getScreen()))
					.collect(Collectors.toList()));
		}

		return responseStructure;

	}
}

