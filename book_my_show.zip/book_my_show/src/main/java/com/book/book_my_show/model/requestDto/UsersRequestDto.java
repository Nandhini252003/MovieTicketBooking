package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

public class UsersRequestDto {

	@NotEmpty(message = "User name cannot be empty")
	private String userName;

	@NotEmpty(message = "Email cannot be empty")
	@Email(message = "Email should be valid")
	private String email;

	@NotEmpty(message = "Phone number cannot be empty")
	@Pattern(regexp = "^\\+?[0-9]{10,15}$", message = "Phone number must be a valid format")
	private String phone;

	@NotNull(message = "Address ID cannot be null")
	@Positive(message = "Address ID must be positive")
	private int addressId;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
}
