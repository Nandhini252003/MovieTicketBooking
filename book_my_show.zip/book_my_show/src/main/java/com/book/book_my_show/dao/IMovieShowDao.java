package com.book.book_my_show.dao;

import java.util.List;
import com.book.book_my_show.model.entity.MovieShow;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.model.entity.Theatre;

public interface IMovieShowDao {
	public List<MovieShow> getAllMovieShows();

	List<MovieShow> getMovieShowByMovieName(String movieName);

	public List<MovieShow> getAllShowsByTheatreId(int theatreId);

	public Movie getMovieByName(String movieName);

	public List<MovieShow> getMovieShowsByMovieAndTheatre(int movieId, List<Theatre> theatres);

	public List<MovieShow> searchMovieShows(String movieName, String screen, String city);

	public List<MovieShow> findByMovieMovieNameAndTheatreAddressCity(String movieName, String city);

	public MovieShow movieShowById(int movieShowId);

//	public List<MovieShow> findByMovieMovieNameAndTheatreAddressCity(String movieName, String city);
	public MovieShow saveMovieShow(MovieShow movieShow);
}
