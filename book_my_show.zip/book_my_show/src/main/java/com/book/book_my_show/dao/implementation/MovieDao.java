package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.IMovieDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.repository.MovieRepository;

@Repository
public class MovieDao implements IMovieDao {
	@Autowired
	private MovieRepository movieRepository;

	@Override
	public Movie getMovieByName(String movieName) {
		Movie movie = movieRepository.findByMovieName(movieName);
		if (movie == null) {
			throw new DataNotFoundException("Movie data is not available.");
		} else {
			return movie;
		}
	}
	@Override
	public List<Movie> getMovieDetails() {
		List<Movie> movie = movieRepository.findAll();
		if (movie.isEmpty()) {
			throw new DataNotFoundException("Movie data is not available.");
		} else {
			return movie;
		}
	}

	@Override
	public Movie getMovieByMovieId(int movieId) {
		Optional<Movie> optionalMovie = movieRepository.findById(movieId);
		if (optionalMovie.isPresent()) {
			return optionalMovie.get();
		} else {
			throw new DataNotFoundException("Movie not found with id: " + movieId);
		}
	}

	@Override
	public Movie saveMovie(Movie movie) {
		return movieRepository.save(movie);
	}
	public Movie getMovieById(int movieId) {
		Optional<Movie> movie = movieRepository.findById(movieId);
		if (movie.isPresent()) {
			System.out.println("address found:"+movie.get());
			return movie.get();
		}
		else
			throw new DataNotFoundException("Movie not found with given id");
	
}
	@Override
	public List<Movie> getMoviesByPrefix(String prefix) {
		List<Movie> movies = movieRepository.findByMovieNameStartingWithIgnoreCase(prefix);
        if (movies.isEmpty()) {
            throw new DataNotFoundException("No movies found with the given prefix: " + prefix);
        }
        return movies;
	}
	@Override
	public List<Movie> getMoviesWithTicketPriceLessThan(int price) {
		return movieRepository.findByTicketBasePriceLessThan(price);
	}
	@Override
	public List<Movie> findByMovieNameContaining(String name) {
		return movieRepository.findByMovieNameContaining(name);
	}
	@Override
    public List<Movie> findMoviesByTicketPriceBetween(int minPrice, int maxPrice) {
        return movieRepository.findByTicketBasePriceBetween(minPrice, maxPrice);
    }
}


