package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.UsersRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.UsersResponseDto;
import com.book.book_my_show.service.IUsersService;
import jakarta.validation.Valid;

@RequestMapping("/api/users")
@RestController
public class UsersController {

    @Autowired
    private IUsersService iUsersService;

    @GetMapping("/state/{state}")
    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> userUserDetailsByState(@PathVariable String state) {
        return iUsersService.getUsersByState(state);
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<ResponseStructure<UsersResponseDto>> updateUser(@PathVariable int userId,
            @RequestBody @Valid UsersRequestDto userRequestDto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
        	ResponseStructure<UsersResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
        }
        return iUsersService.updateUser(userId, userRequestDto);
    }

    @GetMapping
    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getAllUsers() {
        return iUsersService.getAllUsers();
    }

    @GetMapping("/id/{userId}")
    public ResponseEntity<ResponseStructure<UsersResponseDto>> getUserById(@PathVariable int userId) {
        return iUsersService.getUser(userId);
    }

    @GetMapping("/city/{city}")
    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> userDetailsByCity(@PathVariable String city) {
        return iUsersService.getUsersByCity(city);
    }

    @GetMapping("/userid/{userId}")
    public ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserId(@PathVariable int userId) {
        return iUsersService.userDetailsByUserId(userId);
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<ResponseStructure<UsersResponseDto>> getUserByEmail(@PathVariable String email) {
        return iUsersService.getUserByEmail(email);
    }

    @PostMapping("/{userId}")
    public ResponseEntity<ResponseStructure<UsersResponseDto>> assignUserAddressByUserId(@PathVariable int userId,
            @RequestBody @Valid UsersRequestDto usersRequestDto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
        	ResponseStructure<UsersResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
        }
        return iUsersService.assignUserAddressByUserId(userId, usersRequestDto);
    }

    @GetMapping("/name/{username}")
    public ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserName(@PathVariable String username) {
        return iUsersService.userDetailsByUserName(username);
    }

    @GetMapping("/search/username/startwith")
    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findByUserNameStartingWith(@RequestParam String namePrefix) {
        return iUsersService.findByUserNameStartingWith(namePrefix);
    }

    @GetMapping("/search/phone/startwith")
    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findUsersByPhoneStartingWith(@RequestParam String phonePrefix) {
        return iUsersService.findUsersByPhoneStartingWith(phonePrefix);
    }

    @GetMapping("/search/id/greaterthan")
    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findByUserIdGreaterThan(@RequestParam int userId) {
        return iUsersService.findByUserIdGreaterThan(userId);
    }

    @GetMapping("/movies/{userId}")
    public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesForUserId(@PathVariable int userId) {
        return iUsersService.getMoviesForUserId(userId);
    }
}
