package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class MovieRequestDto {

    @NotNull(message = "Movie name cannot be null")
    @NotEmpty(message = "Movie name cannot be empty")
    @Size(min = 2, max = 100, message = "Movie name should be between 2 and 100 characters")
    private String movieName;

    @NotNull(message = "Ticket base price cannot be null")
    @Min(value = 1, message = "Ticket base price should be at least 1")
    private int ticketBasePrice;

    // Getters and Setters
    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public int getTicketBasePrice() {
        return ticketBasePrice;
    }

    public void setTicketBasePrice(int ticketBasePrice) {
        this.ticketBasePrice = ticketBasePrice;
    }
}
