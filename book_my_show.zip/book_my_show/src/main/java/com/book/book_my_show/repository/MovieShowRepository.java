package com.book.book_my_show.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.book.book_my_show.model.entity.MovieShow;
import com.book.book_my_show.model.entity.Theatre;

public interface MovieShowRepository extends JpaRepository<MovieShow, Integer> {

	@Query("SELECT ms FROM MovieShow ms JOIN ms.movie m WHERE m.movieName = :movieName")
	List<MovieShow> getMovieShowByMovieName(String movieName);

	List<MovieShow> findByMovieMovieNameAndTheatreAddressCity(String movieName, String city);


	List<MovieShow> findAllByTheatre_TheatreId(int theatreId);
	@Query("SELECT ms FROM MovieShow ms WHERE ms.movie.movieId = :movieId AND ms.theatre IN :theatres")
	List<MovieShow> findMovieShowsByMovieAndTheatre(int movieId, List<Theatre> theatres);

	@Query("SELECT ms.movie.movieId FROM MovieShow ms WHERE ms.showId IN :showIds")
	List<Integer> findMovieIdsByShowIds(List<Integer> showIds);
	@Query("SELECT ms FROM MovieShow ms WHERE ms.movie.movieName = :movieName AND ms.theatre.screen = :screen AND ms.theatre.address.city = :city")
	List<MovieShow> findMovieShows(String movieName, String screen, String city);
}
