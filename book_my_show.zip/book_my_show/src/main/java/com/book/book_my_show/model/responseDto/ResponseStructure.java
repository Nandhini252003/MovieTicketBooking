package com.book.book_my_show.model.responseDto;

import java.util.Objects;

public class ResponseStructure<T> {
	private int statusCode;
	private String message;
	private T data;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	@Override
	public String toString() {
	    return "ResponseStructure(statusCode=" + statusCode + ", message=" + message + ", data=" + data + ")";
	}

	@Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ResponseStructure<?> that = (ResponseStructure<?>) obj;
        return statusCode == that.statusCode && 
               Objects.equals(message, that.message) && 
               Objects.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(statusCode, message, data);
    }
	public ResponseStructure(int statusCode, String message, T data) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.data = data;
	}
	public ResponseStructure() {
	}
}