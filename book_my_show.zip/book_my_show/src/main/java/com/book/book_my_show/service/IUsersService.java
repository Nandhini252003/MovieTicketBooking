package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;

import com.book.book_my_show.model.entity.Users;
import com.book.book_my_show.model.requestDto.UsersRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.UsersResponseDto;

public interface IUsersService {
	// List<UsersResponseDto> getAllUsers();
	// ResponseEntity<ResponseStructure<List<UsersResponseDto>>>
	// getUsersByCity(String city);
	ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserId(int userId);

	ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getUsersByState(String state);

	ResponseEntity<ResponseStructure<UsersResponseDto>> updateUser(int userId, UsersRequestDto usersRequestDto);

	ResponseEntity<ResponseStructure<UsersResponseDto>> getUserByEmail(String email);

    ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getAllUsers();
    ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getUsersByCity(String city);
    ResponseEntity<ResponseStructure<UsersResponseDto>> assignUserAddressByUserId(int userId,UsersRequestDto usersRequestDto);
	ResponseEntity<ResponseStructure<UsersResponseDto>> getUser(int userId); 
	ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserName(String username); 
    ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findUsersByPhoneStartingWith(String namePrefix);
	ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findByUserNameStartingWith(String namePrefix);
    ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findByUserIdGreaterThan(int userId);
	ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesForUserId(int userId);

//
//	ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getAllUsers();
//
//	ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getUsersByCity(String city);
//
//	ResponseEntity<ResponseStructure<UsersResponseDto>> assignUserAddressByUserId(int userId,
//			UsersRequestDto usersRequestDto);
//
//	ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserName(String username);
//
//	ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesForUserId(int userId);
//
//	ResponseEntity<ResponseStructure<UsersResponseDto>> getUser(int userId);

}
