package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class AddressRequestDto {

	@NotNull(message = "Country cannot be null")
	@NotEmpty(message = "Country cannot be empty")
	@Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String country;
	@NotNull(message = "Country cannot be null")
	@NotEmpty(message = "Country cannot be empty")
	@Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String state;
	@NotNull(message = "Country cannot be null")
	@NotEmpty(message = "Country cannot be empty")
	@Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String city;
	@NotNull(message = "Country cannot be null")
	@NotEmpty(message = "Country cannot be empty")
	@Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String addressLine;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
}
