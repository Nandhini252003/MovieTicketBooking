package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.IUsersDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Users;
import com.book.book_my_show.repository.UsersRepository;

@Repository
public class UsersDao implements IUsersDao {

	@Autowired
	private UsersRepository usersRepository;

	@Override
	public List<Users> getAllUsers() {
		return usersRepository.findAll();
	}

	@Override
	public List<Users> getUserByCity(String city) {
		List<Users> user = usersRepository.findUserByCity(city);
		if (user.isEmpty()) {
			throw new DataNotFoundException("This City is Not exciting in DataBase.");
		} else
			return user;
	}

	@Override
	public Users userDetailsByUserId(int userId) {
		return usersRepository.findById(userId).get();
	}

	@Override
	public List<Users> getUserByState(String state) {
		List<Users> user = usersRepository.findUserByState(state);
		if (user.isEmpty()) {
			throw new DataNotFoundException("This State is Not exciting in DataBase.");
		} else
			return user;
	}

	@Override
	public Users getUserById(int userId) {
		Optional<Users> optional = usersRepository.findById(userId);
		if (optional.isEmpty()) {
			throw new DataNotFoundException("User not found for given id:" + userId);
		}
		return optional.get();
	}

	@Override
	public Users saveUser(Users user) {
		return usersRepository.save(user);
	}

	public boolean findUsertId(int userId) {
		return usersRepository.existsById(userId);
	}

	@Override
	public Users userDetailsByUserName(String username) {

		Optional<Users> user = usersRepository.findUserByUserName(username);
		if (user.isEmpty()) {
			throw new DataNotFoundException("The User with given name:" + username + " doesnot exist");
		} else
			return user.get();
	}

	@Override
	public Users findUserById(int userId) {
		return usersRepository.findById(userId).get();
	}

	@Override
	public Users getUserByEmail(String email) {
		Users user = usersRepository.findUserByEmail(email); // Assuming this method exists in your repository
		if (user == null) {
			throw new DataNotFoundException("No user found with the given email.");
		} else {
			return user;

		}
	}


    @Override
    public List<Users> findByUserNameStartingWith(String namePrefix) {
        return usersRepository.findByUserNameStartingWith(namePrefix);
    }

    @Override
    public List<Users> findUsersByPhoneStartingWith(String phonePrefix) {
        return usersRepository.findByPhoneStartingWith(phonePrefix);
    }
    @Override
    public List<Users> findByUserIdGreaterThan(int userId) {
       return usersRepository.findByUserIdGreaterThan(userId);
        
    }
    }





