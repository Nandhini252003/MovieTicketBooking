package com.book.book_my_show.model.responseDto;



public class TheatreResponseDto {
	private int theatreId;
	private int address;
	private String theatreName;
	private int capacity;
	private String screen;
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	public int getAddress() {
		return address;
	}
	public void setAddressId(int address) {
		this.address = address;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public String getScreen() {
		return screen;
	}
	public void setScreen(String screen) {
		this.screen = screen;
	}
	public TheatreResponseDto(int theatreId, int address, String theatreName, int capacity, String screen) {
		super();
		this.theatreId = theatreId;
		this.address = address;
		this.theatreName = theatreName;
		this.capacity = capacity;
		this.screen = screen;
	}
	public TheatreResponseDto() {
	}
}
