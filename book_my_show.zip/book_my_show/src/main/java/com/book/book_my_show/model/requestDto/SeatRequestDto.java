package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class SeatRequestDto {

	@NotEmpty(message = "Seat number cannot be empty")
	private String seatNumber;

	@NotNull(message = "Tier ID cannot be null")
	@Positive(message = "Tier ID must be a positive value")
	private int tierId;

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public int getTierId() {
		return tierId;
	}

	public void setTierId(int tierId) {
		this.tierId = tierId;
	}
}
