package com.book.book_my_show.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.book.book_my_show.model.entity.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, Integer> {
	@Query("SELECT u FROM Users u WHERE u.address.city = :city")
	List<Users> findUserByCity(@Param("city") String city);

	@Query("SELECT u FROM Users u WHERE u.address.state = :state")
	List<Users> findUserByState(@Param("state") String state);

	Users findUserByEmail(String email);

	Optional<Users> findUserByUserName(String username);

	List<Users> findByUserIdGreaterThan(int userId);

	List<Users> findByUserNameStartingWith(String namePrefix);

	List<Users> findByPhoneStartingWith(String phonePrefix);

}
