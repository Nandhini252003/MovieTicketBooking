package com.book.book_my_show.dao.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.IOfferDao;
import com.book.book_my_show.repository.OfferRepository;

@Repository
public class OfferDao implements IOfferDao {
	@Autowired
	private OfferRepository offerRepository;
}
