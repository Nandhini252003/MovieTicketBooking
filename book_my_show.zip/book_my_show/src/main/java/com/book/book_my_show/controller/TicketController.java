package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.TicketRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TicketResponseDto;
import com.book.book_my_show.service.ITicketService;

import jakarta.validation.Valid;

@RequestMapping("/api/tickets")
@RestController
public class TicketController {

	@Autowired
	private ITicketService iTicketService;

	@GetMapping
	public ResponseEntity<List<TicketResponseDto>> getAllTickets() {
		List<TicketResponseDto> ticketResponseDtos = iTicketService.getAllTickets();
		return ResponseEntity.ok(ticketResponseDtos);
	}

	@PostMapping("/save")
	public ResponseEntity<ResponseStructure<TicketResponseDto>> addTicket(
			@RequestBody @Valid TicketRequestDto ticketRequestDto) {

		
		return iTicketService.addTicket(ticketRequestDto);
	}

	@GetMapping("/{ticketId}")
	public ResponseEntity<ResponseStructure<TicketResponseDto>> getTicketById(@PathVariable int ticketId) {
		return iTicketService.getTicketById(ticketId);
	}
}
