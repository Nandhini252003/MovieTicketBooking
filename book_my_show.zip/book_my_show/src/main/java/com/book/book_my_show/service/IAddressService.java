package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;

public interface IAddressService {
	 ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAddressesByCity(String city);
	 ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAddressesByState(String state);
    //List<AddressResponseDto> getAddressesByCity(String city);
    ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAllAddress();
    ResponseEntity<ResponseStructure<AddressResponseDto>> getAddressById(int addressId);
	ResponseEntity<ResponseStructure<AddressResponseDto>> AddNewAddress(AddressRequestDto addressRequestDto);
	public ResponseEntity<ResponseStructure<AddressResponseDto>> updateAddressById(AddressRequestDto addressRequestDto,
			int addressId);
	ResponseEntity<ResponseStructure<TheatreResponseDto>> getMaxTheatreCapacityByCity(String city);
}
