package com.book.book_my_show.dao;

import java.util.List;
import com.book.book_my_show.model.entity.Address;

public interface IAddressDao {
	public List<Address> getAddressesByState(String state);
	public List<Address> getAllAddresses();

	public Address getAddressById(int addressId);

	public List<Address> getAddressesByCity(String city);

	public Address findById(int addressId);

	public Address getaddressById(int addressId);

	public Address saveAddress(Address address);

	public boolean findAddressId(int addressId);

	public Address findUserById(int addressId);

}
