package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.TierRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TierResponseDto;
import com.book.book_my_show.service.ITierService;
import jakarta.validation.Valid;

@RequestMapping("/api/tiers")
@RestController
public class TierController {

    @Autowired
    private ITierService iTierService;

    @GetMapping("/{id}")
    public ResponseEntity<ResponseStructure<List<TierResponseDto>>> getAllTiersByTheatreId(@PathVariable int id) {
        return iTierService.getAllTiers(id);
    }

    @PostMapping
    public ResponseEntity<ResponseStructure<TierResponseDto>> saveTier(
            @RequestBody @Valid TierRequestDto tierRequestDto, BindingResult bindingResult) {

        // If there are validation errors, return a bad request response
        if (bindingResult.hasErrors()) {
        	ResponseStructure<TierResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
        }
        return iTierService.saveTier(tierRequestDto);
    }

    @PutMapping("/{theatre_id}/{tier_id}")
    public ResponseEntity<ResponseStructure<List<TierResponseDto>>> updateTierByIds(
            @RequestBody @Valid TierRequestDto tier, @PathVariable int theatre_id, @PathVariable int tier_id,
            BindingResult bindingResult) {

        // If there are validation errors, return a bad request response
        if (bindingResult.hasErrors()) {
        	ResponseStructure<List<TierResponseDto>> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
        }
        return iTierService.updateTier(tier, theatre_id, tier_id);
    }
}
