package com.book.book_my_show.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.service.IAddressService;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RequestMapping("/api/addresses")
@RestController
@Tag(name = "Movie Ticket Booking Portal API", description = "API endpoints that gives All The Endpoints of Movie Ticket Booking Portal ")
public class AddressController {

	@Autowired
	private IAddressService iAddressService;

	@GetMapping("/city/{city}")
	public ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAddressesByCity(@PathVariable String city) {
		return iAddressService.getAddressesByCity(city);
	}

	@GetMapping("/state/{state}")
	public ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAddressesByState(@PathVariable String state) {
		return iAddressService.getAddressesByState(state);
	}

	@GetMapping
	public ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAllAddress() {
		return iAddressService.getAllAddress();
	}

	@GetMapping("/{addressId}")
	public ResponseEntity<ResponseStructure<AddressResponseDto>> getAddressById(@PathVariable int addressId) {
		return iAddressService.getAddressById(addressId);
	}

	@PostMapping
	public ResponseEntity<ResponseStructure<AddressResponseDto>> AddAddress(
			@RequestBody @Valid AddressRequestDto addressRequestDto) {
		return iAddressService.AddNewAddress(addressRequestDto);
	}

	@PutMapping("/update/{addressId}")
	public ResponseEntity<ResponseStructure<AddressResponseDto>> updateAddressById(
			@RequestBody @Valid AddressRequestDto addressRequestDto, @PathVariable int addressId) {
		return iAddressService.updateAddressById(addressRequestDto, addressId);
	}

	@GetMapping("/theatre/{city}")
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> getMaxTheatreCapacityByCity(
			@PathVariable String city) {
		return iAddressService.getMaxTheatreCapacityByCity(city);
	}
}
