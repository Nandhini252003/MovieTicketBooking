package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.PaymentRequestDto;
import com.book.book_my_show.model.responseDto.PaymentResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.IPaymentService;

import jakarta.validation.Valid;

@RequestMapping("/api/payments")
@RestController
public class PaymentController {

	@Autowired
	private IPaymentService iPaymentService;

	@GetMapping("/user/{userId}")
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentDetailsByUserId(
			@PathVariable int userId) {
		return iPaymentService.getPaymentDetailsByUserId(userId);
	}

	@GetMapping
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getAllPayments() {
		return iPaymentService.getAllPayments();
	}

	@GetMapping("/{paymentId}")
	public ResponseEntity<ResponseStructure<PaymentResponseDto>> getPaymentById(@PathVariable int paymentId) {
		return iPaymentService.getPaymentById(paymentId);
	}

	@PostMapping("/")
	public ResponseEntity<ResponseStructure<PaymentResponseDto>> addPayment(
			@RequestBody @Valid PaymentRequestDto paymentRequestDto, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			ResponseStructure<PaymentResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed" + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
		}
		return iPaymentService.addPayment(paymentRequestDto);
	}

	@GetMapping("/status/{paymentStatus}")
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> searchPaymentByStatus(
			@PathVariable String paymentStatus) {
		return iPaymentService.getPaymentByStatus(paymentStatus);
	}
}
