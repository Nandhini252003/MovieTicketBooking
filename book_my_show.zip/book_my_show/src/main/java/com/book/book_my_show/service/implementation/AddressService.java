package com.book.book_my_show.service.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.repository.TheatreRepository;
import com.book.book_my_show.service.IAddressService;

@Service
public class AddressService implements IAddressService {
	@Autowired
	private IAddressDao iAddressDao;
	
	@Autowired
	private TheatreRepository theatreRepository;

		
		@Override
	    public ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAddressesByCity(String city) {
	        List<Address> addresses = iAddressDao.getAddressesByCity(city);
	        List<AddressResponseDto> addressResponseDtos = new ArrayList<>();
	        for (Address address : addresses) 
	        {
	            AddressResponseDto addressResponseDto = new AddressResponseDto();
	            addressResponseDto.setAddressId(address.getAddressId());
	            addressResponseDto.setAddressLine(address.getAddressLine());
	            addressResponseDto.setCountry(address.getCountry());
	            addressResponseDto.setState(address.getState());
	            addressResponseDto.setCity(address.getCity());
	            addressResponseDtos.add(addressResponseDto);
	        }
	        ResponseStructure<List<AddressResponseDto>> response = new ResponseStructure<>();
            response.setData(addressResponseDtos);
            response.setMessage("City found");
            response.setStatusCode(HttpStatus.FOUND.value());
            return new ResponseEntity<>(response, HttpStatus.FOUND);
	    }

		@Override
		public ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAddressesByState(String state) {
		    List<Address> addresses = iAddressDao.getAddressesByState(state);
		    List<AddressResponseDto> addressResponseDtos = addresses.stream()
		        .map(address -> {
		            AddressResponseDto addressResponseDto = new AddressResponseDto();
		            addressResponseDto.setAddressId(address.getAddressId());
		            addressResponseDto.setAddressLine(address.getAddressLine());
		            addressResponseDto.setCountry(address.getCountry());
		            addressResponseDto.setState(address.getState());
		            addressResponseDto.setCity(address.getCity());
		            return addressResponseDto;
		        })
		        .collect(Collectors.toList());
		    ResponseStructure<List<AddressResponseDto>> response = new ResponseStructure<>();
		    response.setData(addressResponseDtos);  // Corrected to pass the list of DTOs
		    response.setMessage("Addresses found for state: " + state);
		    response.setStatusCode(HttpStatus.FOUND.value());
		    return new ResponseEntity<>(response, HttpStatus.FOUND);
		}

	@Override
	public ResponseEntity<ResponseStructure<List<AddressResponseDto>>> getAllAddress() {
		List<Address> addresses = iAddressDao.getAllAddresses();
		List<AddressResponseDto> addressResponseDtos = new ArrayList<>();
		for (Address address : addresses) {
			AddressResponseDto addressResponseDto = new AddressResponseDto();
			addressResponseDto.setAddressId(address.getAddressId());
			addressResponseDto.setAddressLine(address.getAddressLine());
			addressResponseDto.setCountry(address.getCountry());
			addressResponseDto.setState(address.getState());
			addressResponseDto.setCity(address.getCity());
			addressResponseDtos.add(addressResponseDto);
		}
		ResponseStructure<List<AddressResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Success");
		responseStructure.setData(addressResponseDtos);
		return new ResponseEntity<ResponseStructure<List<AddressResponseDto>>>(responseStructure, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<AddressResponseDto>> getAddressById(int addressId) {
		Address addresses = iAddressDao.getAddressById(addressId);
		AddressResponseDto addressResponseDto = new AddressResponseDto();
		addressResponseDto.setAddressId(addresses.getAddressId());
		addressResponseDto.setCountry(addresses.getCountry());
		addressResponseDto.setState(addresses.getState());
		addressResponseDto.setCity(addresses.getCity());
		addressResponseDto.setAddressLine(addresses.getAddressLine());
		ResponseStructure<AddressResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("success");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(addressResponseDto);
		return new ResponseEntity<ResponseStructure<AddressResponseDto>>(responseStructure, HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<AddressResponseDto>> AddNewAddress(AddressRequestDto addressRequestDto) {
		Address address = new Address();
		address.setAddressLine(addressRequestDto.getAddressLine());
		address.setCity(addressRequestDto.getCity());
		address.setCountry(addressRequestDto.getCountry());
		address.setState(addressRequestDto.getState());
		Address savedAddress = iAddressDao.saveAddress(address);
		AddressResponseDto addressResponseDto = new AddressResponseDto();
		addressResponseDto.setAddressId(savedAddress.getAddressId());
		addressResponseDto.setAddressLine(savedAddress.getAddressLine());
		addressResponseDto.setCity(savedAddress.getCity());
		addressResponseDto.setCountry(savedAddress.getCountry());
		addressResponseDto.setState(savedAddress.getState());
		ResponseStructure<AddressResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Record Created Successfully.");
		response.setData(addressResponseDto);
		return new ResponseEntity<ResponseStructure<AddressResponseDto>>(response, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ResponseStructure<AddressResponseDto>> updateAddressById(AddressRequestDto addressRequestDto,
			int addressId) {
		
		Address address = iAddressDao.getaddressById(addressId);
                
        address.setCity(addressRequestDto.getCity());
        address.setState(addressRequestDto.getState());
        address.setAddressLine(addressRequestDto.getAddressLine());
        address.setCountry(addressRequestDto.getCountry());

        Address updatedAddress = iAddressDao.saveAddress(address);

        AddressResponseDto addressResponseDto = new AddressResponseDto();
        addressResponseDto.setAddressId(updatedAddress.getAddressId());
        addressResponseDto.setCity(updatedAddress.getCity());
        addressResponseDto.setState(updatedAddress.getState());
        addressResponseDto.setCountry(updatedAddress.getCountry());
        addressResponseDto.setAddressLine(updatedAddress.getAddressLine());

        ResponseStructure<AddressResponseDto> responseStructure = new ResponseStructure<>();
        responseStructure.setStatusCode(HttpStatus.FOUND.value());
        responseStructure.setMessage("Record Updated Successfully.");
        responseStructure.setData(addressResponseDto);
        return new ResponseEntity<>(responseStructure, HttpStatus.OK);
    }

	@Override
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> getMaxTheatreCapacityByCity(String city) {
		
		List<Address> address = iAddressDao.getAddressesByCity(city);
		
		Theatre maxCapT = null;
		int maxCapacity=0;
		
		for(Address a : address) {
			List<Theatre> t = theatreRepository.findByAddress_AddressId(a.getAddressId());
			for(Theatre i:t) {
				if(i.getCapacity()>maxCapacity) {
					maxCapacity=i.getCapacity();
					maxCapT=i;
				}
			}
			
		}
		
		if (maxCapT != null) {
	        TheatreResponseDto responseDto = new TheatreResponseDto();
	        responseDto.setTheatreName(maxCapT.getTheatreName());
	        responseDto.setCapacity(maxCapT.getCapacity());
	        responseDto.setAddressId(maxCapT.getAddress().getAddressId());
	        responseDto.setTheatreId(maxCapT.getTheatreId());
	        responseDto.setScreen(maxCapT.getScreen());
	        
	        ResponseStructure<TheatreResponseDto> responseStructure = new ResponseStructure<>();
	        responseStructure.setStatusCode(HttpStatus.OK.value());
	        responseStructure.setMessage("Max Capacity Theatre");
	        responseStructure.setData(responseDto);
	        
	        return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	    } else {
	       
	        ResponseStructure<TheatreResponseDto> responseStructure = new ResponseStructure<>();
	        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
	        responseStructure.setMessage("No theatres found for the given city");
	        
	        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
	    }
		
		
	}
	
	
}
