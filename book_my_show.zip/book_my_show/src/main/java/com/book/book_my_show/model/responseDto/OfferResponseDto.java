package com.book.book_my_show.model.responseDto;

public class OfferResponseDto {
	private int offerId;
	private int movieShowId;
	private String offerDetails;
	public int getOfferId() {
		return offerId;
	}
	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}
	public int getMovieShow() {
		return movieShowId;
	}
	public void setMovieShow(int movieShowId) {
		this.movieShowId = movieShowId;
	}
	public String getOfferDetails() {
		return offerDetails;
	}
	public void setOfferDetails(String offerDetails) {
		this.offerDetails = offerDetails;
	}
	public OfferResponseDto(int offerId, int movieShowId, String offerDetails) {
		super();
		this.offerId = offerId;
		this.movieShowId = movieShowId;
		this.offerDetails = offerDetails;
	}
	public OfferResponseDto() {
	}
}
