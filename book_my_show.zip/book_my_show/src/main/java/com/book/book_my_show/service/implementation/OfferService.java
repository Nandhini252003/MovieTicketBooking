package com.book.book_my_show.service.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IOfferDao;
import com.book.book_my_show.service.IOfferService;

@Service
public class OfferService implements IOfferService{
	@Autowired
	private IOfferDao iOfferDao;
}
