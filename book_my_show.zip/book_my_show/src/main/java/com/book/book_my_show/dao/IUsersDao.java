package com.book.book_my_show.dao;

import java.util.List;
import java.util.Optional;
import com.book.book_my_show.model.entity.Users;

public interface IUsersDao {
	List<Users> getUserByCity(String city);
	List<Users> getAllUsers();
	Users userDetailsByUserId(int userId);
	List<Users> getUserByState(String state);
	Users getUserById(int userId);
	Users saveUser(Users user );
	boolean findUsertId(int ticketId);
	Users findUserById(int userId);
	Users getUserByEmail(String email);
	Users userDetailsByUserName(String username);
	

    List<Users> findByUserNameStartingWith(String namePrefix);
	List<Users> findUsersByPhoneStartingWith(String phonePrefix);
    List<Users> findByUserIdGreaterThan(int userId);

}
