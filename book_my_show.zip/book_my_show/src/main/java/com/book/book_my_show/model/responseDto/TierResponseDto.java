package com.book.book_my_show.model.responseDto;


public class TierResponseDto {
	private int tierId;
	private String tierName;
//	private TheatreResponseDto theatreResponseDto;
	private int theatreId;
	private int ticketPriceMultiplier;
	public int getTierId() {
		return tierId;
	}
	public void setTierId(int tierId) {
		this.tierId = tierId;
	}
	public String getTierName() {
		return tierName;
	}
	public void setTierName(String tierName) {
		this.tierName = tierName;
	}
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	public int getTicketPriceMultiplier() {
		return ticketPriceMultiplier;
	}
	public void setTicketPriceMultiplier(int ticketPriceMultiplier) {
		this.ticketPriceMultiplier = ticketPriceMultiplier;
	}
	public TierResponseDto(int tierId, String tierName, int theatreId, int ticketPriceMultiplier) {
		super();
		this.tierId = tierId;
		this.tierName = tierName;
		this.theatreId = theatreId;
		this.ticketPriceMultiplier = ticketPriceMultiplier;
	}
	public TierResponseDto() {
	}
}
