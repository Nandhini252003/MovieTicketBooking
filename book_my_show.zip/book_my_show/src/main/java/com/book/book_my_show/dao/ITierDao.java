package com.book.book_my_show.dao;

import java.util.List;
import com.book.book_my_show.model.entity.Tier;

public interface ITierDao {
	List<Tier> findTiersByTheatreId(int id);

	public Tier saveTier(Tier tier);

	public Tier getTierById(int tierId);

	Boolean findTierId(int tierId);

	Tier findTierById(int tierId);
}