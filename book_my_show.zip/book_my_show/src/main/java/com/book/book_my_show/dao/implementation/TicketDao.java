package com.book.book_my_show.dao.implementation;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.ITicketDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Ticket;
import com.book.book_my_show.model.responseDto.TicketResponseDto;
import com.book.book_my_show.repository.TicketRepository;

@Repository
public class TicketDao implements ITicketDao {
	@Autowired
	private TicketRepository ticketRepository;

	@Override
	public List<Ticket> getAllTickets() {
		return ticketRepository.findAll();
	}

	@Override
	public Ticket addNewTicket(Ticket ticket) {
		return ticketRepository.save(ticket);
	}
	public boolean findTicketId(int ticketId) {
		return ticketRepository.existsById(ticketId);
	}

	@Override
    public Ticket findTicketById(int ticketId) {
        return ticketRepository.findById(ticketId)
            .orElseThrow(() -> new DataNotFoundException("Ticket with id " + ticketId + " not found."));
    }
	@Override
	public Ticket getTicketById(int ticketId) {
		return ticketRepository.findById(ticketId).get();
	}

	@Override
	public List<TicketResponseDto> findByMovieShow_Theatre_TheatreId(int theatreId) {
		
		
	        return ticketRepository.findByMovieShow_Theatre_TheatreId(theatreId);
	    
	}

	@Override
	public int countTicketsByTheatreId(int theatreId) {
		return ticketRepository.countTicketsByTheatreId(theatreId);
	}

	@Override
	public Ticket findTicketBySeatAndMovieShow(int seatId, int showId) {
		Ticket ticket = ticketRepository.findTicketBySeatAndMovieShow(seatId, showId);
	    
	    return ticket;
	}

	
}
