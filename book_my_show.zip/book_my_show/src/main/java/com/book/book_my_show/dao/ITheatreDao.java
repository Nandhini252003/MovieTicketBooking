package com.book.book_my_show.dao;

import java.util.List;
import java.util.Optional;

import com.book.book_my_show.model.entity.Theatre;

public interface ITheatreDao {
	public List<Theatre> getAllTheatres();

	public Theatre save(Theatre theatre);
	public  List<Theatre> getTheatreByCity(String city);

	public Theatre theatreDetailsByName(String theatreName);

	public Theatre getTheatreById(int theatreid);

	public Theatre findById(int theatreId);

	public Theatre saveTheatre(Theatre theatre);

	public List<Theatre> findByAddressCountry(String country);

	public Theatre getTheatreByName(String name);

	public List<Theatre> getTheatresByCityAndScreen(int addressId, String screenType);

	boolean findTheatreId(int theatre_id);

	public Theatre findTheatreById(int theatreId);
	

	public Optional<Theatre> getTheatreWithMaxCapacity();
	public List<String> findTheatresInAlphabeticalOrder();
	public List<Theatre> getTheatresByCapacityRange(int minCapacity, int maxCapacity);
	public List<Theatre> getTheatresByScreenType(String screenType);

	

}
