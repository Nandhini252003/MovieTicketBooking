package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.MovieRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.IMovieService;

import jakarta.validation.Valid;

@RequestMapping("/api/movies")
@RestController
public class MovieController {

	@Autowired
	private IMovieService iMovieService;

	@GetMapping("/{movieName}")
	public ResponseEntity<MovieResponseDto> getMovieByName(@PathVariable String movieName) {
		MovieResponseDto movieResponseDto = iMovieService.getMovieByName(movieName);
		return ResponseEntity.ok(movieResponseDto);
	}

	@GetMapping
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getAllMovieDetails() {
		return iMovieService.getAllMovieDetails();
	}

	@PutMapping("/{movieId}")
	public ResponseEntity<ResponseStructure<MovieResponseDto>> updateMovieDetailsByMovieId(@PathVariable int movieId,
			@RequestBody @Valid MovieRequestDto movieRequestDto) {
		// The movieRequestDto is validated before entering this method.
		return iMovieService.UpdateMovieDetailsByMovieId(movieId, movieRequestDto);
	}

	@GetMapping("/movie/{movieId}")
	public ResponseEntity<ResponseStructure<MovieResponseDto>> getMovieById(@PathVariable int movieId) {
		return iMovieService.getMovieById(movieId);
	}

	@GetMapping("/search")
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> searchMoviesByPrefix(@RequestParam String prefix) {
		return iMovieService.getMoviesByPrefix(prefix);
	}

	@GetMapping("/under-price")
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesUnderPrice(@RequestParam int price) {
		return iMovieService.getMoviesWithTicketPriceLessThan(price);
	}

	@GetMapping("/searchBySubstring")
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> searchMoviesBySubstring(
			@RequestParam String substring) {
		return iMovieService.getMoviesBySubstring(substring);
	}

	@GetMapping("/searchByTicketPriceRange")
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> searchMoviesByTicketPriceRange(
			@RequestParam int minPrice, @RequestParam int maxPrice) {
		return iMovieService.getMoviesByTicketPriceRange(minPrice, maxPrice);
	}
}
