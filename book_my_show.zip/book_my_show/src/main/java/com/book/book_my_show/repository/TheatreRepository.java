package com.book.book_my_show.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.book.book_my_show.model.entity.Theatre;

public interface TheatreRepository extends JpaRepository<Theatre, Integer> {
	Optional<Theatre> findTheatreByTheatreName(String theatreName);
	List<Theatre> findByAddressCountry(String country);

	List<Theatre> findByAddressCity(String city);

	Optional<Theatre> findByTheatreName(String name);
	
	@Query("SELECT t FROM Theatre t WHERE t.address.addressId = :addressId AND t.screen = :screenType")
    List<Theatre> findTheatresByCityAndScreen(int addressId, String screenType);
	
	List<Theatre> findByAddress_AddressIdAndScreen(int addressId, String screenType);


	List<Theatre> findByCapacityBetween(int minCapacity, int maxCapacity);

	List<Theatre> findByScreen(String screenType);
	List<Theatre> findByAddress_AddressId(int addressId);
	
}
