package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.PaymentRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.PaymentResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;

public interface IPaymentService {
	//PaymentRequestDto addPayment(PaymentRequestDto paymentRequestDto);
	ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentDetailsByUserId(int userId); 
	ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getAllPayments();
	ResponseEntity<ResponseStructure<PaymentResponseDto>> getPaymentById(int paymentId);
	ResponseEntity<ResponseStructure<PaymentResponseDto>> addPayment(PaymentRequestDto paymentRequestDto);
	ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentByStatus(String paymentStatus);
	ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentsByUserId(int userId);
}
