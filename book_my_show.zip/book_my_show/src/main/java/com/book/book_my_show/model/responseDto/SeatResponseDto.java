package com.book.book_my_show.model.responseDto;

public class SeatResponseDto {
	private int seatId;
	private String seatNumber;
	private int tierId;
	public int getSeatId() {
		return seatId;
	}
	public void setSeatId(int seatId) {
		this.seatId = seatId;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public int getTierId() {
		return tierId;
	}
	public void setTierId(int tier) {
		this.tierId = tier;
	}
	public SeatResponseDto(int seatId, String seatNumber, int tier) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.tierId = tier;
	}
	public SeatResponseDto() {
	}
}
