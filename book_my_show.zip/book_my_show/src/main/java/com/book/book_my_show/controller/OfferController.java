package com.book.book_my_show.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api/offers")
@RestController
public class OfferController {

}
