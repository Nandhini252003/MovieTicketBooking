package com.book.book_my_show.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.book.book_my_show.model.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

	@Query("SELECT p FROM Payment p WHERE p.paymentStatus =:paymentStatus")
	List<Payment> findByStatus(@Param("paymentStatus") String paymentStatus);

    @Query("SELECT p.ticket.ticketId FROM Payment p WHERE p.user.id = :userId")
	List<Integer> findTicketIdsByUserId(@Param("userId") int userId);

	List<Payment> findByUser_UserId(int userId); 
}

