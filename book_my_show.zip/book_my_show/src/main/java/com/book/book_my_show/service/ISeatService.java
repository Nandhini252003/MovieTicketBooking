package com.book.book_my_show.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.requestDto.SeatRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.SeatResponseDto;

public interface ISeatService {
	ResponseEntity<ResponseStructure<SeatResponseDto>> updateSeatBySeatIdTierId(int seatId, int tierId,
			SeatRequestDto seatRequestDto);
	ResponseEntity<ResponseStructure<SeatResponseDto>> AddSeatByTierId(SeatRequestDto seat, int tierId);

	ResponseEntity<ResponseStructure<SeatResponseDto>> getSeatById(int seatId);
	ResponseEntity<ResponseStructure<List<SeatResponseDto>>> getSeatsBySeatNumber(String seatNumber);


}
