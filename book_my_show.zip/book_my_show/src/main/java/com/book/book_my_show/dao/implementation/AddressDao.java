package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.repository.AddressRepository;

@Repository
public class AddressDao implements IAddressDao {
	@Autowired
	private AddressRepository addressRepository;

	@Override
    public List<Address> getAddressesByCity(String city) {
		List<Address> address =addressRepository.findByCity(city);
			if(address.isEmpty())
			{
				throw new DataNotFoundException("City not found");
			}
			else return address;	
		}

	@Override
	public List<Address> getAddressesByState(String state) {
		List<Address> address =addressRepository.findByState(state);
		if(address.isEmpty())
		{
			throw new DataNotFoundException("State not found");
		}
		else return address;	
	}

	@Override
	public Address getAddressById(int addressId) {
		
		Optional<Address> address = addressRepository.findById(addressId);
		if(address.isEmpty())
		{
			throw new DataNotFoundException("address  not found with given id");
		}
		else return address.get();	
	}
		
	

	@Override
	public List<Address> getAllAddresses() {
		return addressRepository.findAll();
	}

//	@Override
//	public Address getAddressById(int addressId) {
//		Optional<Address> address = addressRepository.findById(addressId);
//		if (address.isPresent()) {
//			System.out.println("address found:" + address.get());
//			return address.get();
//		} else
//			System.out.println("No address found with ID:" + addressId);
//		throw new DataNotFoundException("Validation failed");
//	}

	public Address getaddressById(int addressId) {
		Optional<Address> address = addressRepository.findById(addressId);
		if (address.isPresent()) {
			System.out.println("address found:" + address.get());
			return address.get();
		}

		else
			return address.get();
	}

	@Override
	public Address findById(int addressId) {
		Optional<Address> address = addressRepository.findById(addressId);
		if (address.isEmpty()) {
			throw new DataNotFoundException("No such address is present with the given id");
		}
		return address.get();
	}

//	@Override
//	public List<Address> getAddressesByCity(String city) {
//		List<Address> addressList = addressRepository.findByCity(city);
//		if (addressList.isEmpty()) {
//			throw new DataNotFoundException("City not found");
//		}
//		System.out.println("Addresses found in city " + city + ": " + addressList);
//		return addressList;
//	}

	@Override
	public Address saveAddress(Address address) {
		return addressRepository.save(address);
	}

	@Override
	public boolean findAddressId(int addressId) {
		return addressRepository.existsById(addressId);
	}

	@Override
	public Address findUserById(int addressId) {
		return addressRepository.findById(addressId).get();
	}

}
