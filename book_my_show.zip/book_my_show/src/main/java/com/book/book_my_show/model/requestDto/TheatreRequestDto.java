package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class TheatreRequestDto {

    @NotNull(message = "Address ID cannot be null")
    @Positive(message = "Address ID must be a positive value")
    private int addressId;

    @NotEmpty(message = "Theatre name cannot be empty")
    private String theatreName;

    @NotNull(message = "Capacity cannot be null")
    @Positive(message = "Capacity must be a positive value")
    private int capacity;

    @NotEmpty(message = "Screen type cannot be empty")
    private String screen;

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public String getTheatreName() {
        return theatreName;
    }

    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getScreen() {
        return screen;
    }

    public void setScreen(String screen) {
        this.screen = screen;
    }
}
