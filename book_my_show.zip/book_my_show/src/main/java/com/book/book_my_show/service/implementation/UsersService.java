package com.book.book_my_show.service.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.dao.IUsersDao;
import com.book.book_my_show.exception.DataAlreadyExistsException;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.model.entity.Users;
import com.book.book_my_show.model.requestDto.UsersRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.UsersResponseDto;
import com.book.book_my_show.repository.MovieRepository;
import com.book.book_my_show.repository.MovieShowRepository;
import com.book.book_my_show.repository.PaymentRepository;
import com.book.book_my_show.repository.TicketRepository;
import com.book.book_my_show.service.IUsersService;

@Service
public class UsersService implements IUsersService {
	@Autowired
	private IUsersDao iUsersDao;
	@Autowired
	private IAddressDao iAddressDao;

	@Autowired
	private PaymentRepository paymentRepository;

	@Autowired
	private TicketRepository ticketRepository;

	@Autowired
	private MovieShowRepository movieShowRepository;

	@Autowired
	private MovieRepository movieRepository;

	@Override
	public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getAllUsers() {
		List<Users> userss = iUsersDao.getAllUsers();
		List<UsersResponseDto> usersResponseDtos = new ArrayList<>();
		for (Users users : userss) {
			UsersResponseDto usersResponseDto = new UsersResponseDto();
			usersResponseDto.setUserName(users.getUserName());
			usersResponseDto.setUserId(users.getUserId());
			usersResponseDto.setEmail(users.getEmail());
			usersResponseDto.setPhone(users.getPhone());
			usersResponseDto.setAddressId(users.getAddress().getAddressId());
			usersResponseDtos.add(usersResponseDto);
		}
		ResponseStructure<List<UsersResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(usersResponseDtos);
		return new ResponseEntity<ResponseStructure<List<UsersResponseDto>>>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getUsersByCity(String city) {
		List<Users> users = iUsersDao.getUserByCity(city);
		List<UsersResponseDto> user = users.stream().map(data -> {
			UsersResponseDto dto = new UsersResponseDto();
			dto.setUserId(data.getUserId());
			dto.setUserName(data.getUserName());
			dto.setEmail(data.getEmail());
			dto.setPhone(data.getPhone());
			AddressResponseDto addressResponseDto = new AddressResponseDto();
			if (addressResponseDto != null) {
				addressResponseDto.setAddressId(data.getAddress().getAddressId());
			}
			dto.setAddressId(addressResponseDto.getAddressId());
			return dto;
		}).collect(Collectors.toList());
		ResponseStructure<List<UsersResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(user);
		return new ResponseEntity<ResponseStructure<List<UsersResponseDto>>>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> getUsersByState(String state) {
		List<Users> users = iUsersDao.getUserByState(state);
		List<UsersResponseDto> user = users.stream().map(data -> {
			UsersResponseDto dto = new UsersResponseDto();
			dto.setUserId(data.getUserId());
			dto.setUserName(data.getUserName());
			dto.setEmail(data.getEmail());
			dto.setPhone(data.getPhone());
			AddressResponseDto addressResponseDto = new AddressResponseDto();
			if (addressResponseDto != null) {
				addressResponseDto.setAddressId(data.getAddress().getAddressId());
			}
			dto.setAddressId(addressResponseDto.getAddressId());
			return dto;
		}).collect(Collectors.toList());
		ResponseStructure<List<UsersResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(user);
		return new ResponseEntity<ResponseStructure<List<UsersResponseDto>>>(response, HttpStatus.FOUND);

	}

	@Override
	public ResponseEntity<ResponseStructure<UsersResponseDto>> updateUser(int userId, UsersRequestDto usersRequestDto) {
		Users users = iUsersDao.getUserById(userId);
		if (users == null) {
			throw new DataNotFoundException("User not found for ID: " + userId);
		}
		Address address = iAddressDao.getAddressById(usersRequestDto.getAddressId());
		if (address == null) {
			throw new DataNotFoundException("Address not found for given ID");
		}
		users.setAddress(address);

		users.setUserName(usersRequestDto.getUserName());
		users.setPhone(usersRequestDto.getPhone());
		users.setEmail(usersRequestDto.getEmail());
		Users updatedUser = iUsersDao.saveUser(users);
		UsersResponseDto usersResponseDto = new UsersResponseDto();
		usersResponseDto.setAddressId(updatedUser.getAddress().getAddressId());
		usersResponseDto.setUserName(updatedUser.getUserName());
		usersResponseDto.setEmail(updatedUser.getEmail());
		usersResponseDto.setPhone(updatedUser.getPhone());
		usersResponseDto.setUserId(updatedUser.getUserId());
		ResponseStructure<UsersResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Success");
		response.setData(usersResponseDto);

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ResponseStructure<UsersResponseDto>> getUserByEmail(String email) {

		Users user = iUsersDao.getUserByEmail(email);
		if (user == null) {
			throw new DataNotFoundException("No user found with the given email.");
		}

		UsersResponseDto usersResponseDto = new UsersResponseDto();
		usersResponseDto.setUserId(user.getUserId());
		usersResponseDto.setUserName(user.getUserName());
		usersResponseDto.setEmail(user.getEmail());
		usersResponseDto.setPhone(user.getPhone());

		AddressResponseDto addressResponseDto = new AddressResponseDto();
		if (user.getAddress() != null) {
			addressResponseDto.setAddressId(user.getAddress().getAddressId());
		}
		usersResponseDto.setAddressId(addressResponseDto.getAddressId());

		ResponseStructure<UsersResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(usersResponseDto);

		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<UsersResponseDto>> assignUserAddressByUserId(int userId,
			UsersRequestDto usersRequestDto) {
		Users user = iUsersDao.getUserById(userId);
		if (user.getAddress() != null) {
			throw new DataAlreadyExistsException("the user already has the address");
		}
		Address address = iAddressDao.findById(usersRequestDto.getAddressId());
		if (address == null) {
			throw new DataNotFoundException(
					"there is no such address exists with the given id to aasign it to the user");
		}
		user.setAddress(address);
		Users savedUser = iUsersDao.saveUser(user);

		UsersResponseDto ur = new UsersResponseDto();
		ur.setUserId(savedUser.getUserId());
		ur.setUserName(savedUser.getUserName());
		ur.setPhone(savedUser.getPhone());
		ur.setEmail(savedUser.getEmail());
		ur.setAddressId(savedUser.getAddress().getAddressId());
		ResponseStructure<UsersResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Successfully added");
		response.setData(ur);

	    
	    return new ResponseEntity<ResponseStructure<UsersResponseDto>>(response, HttpStatus.CREATED);
		
	}

	@Override
	public ResponseEntity<ResponseStructure<UsersResponseDto>> getUser(int userId) {
		Users user = iUsersDao.findUserById(userId);
		UsersResponseDto dto = new UsersResponseDto();
		dto.setAddressId(user.getUserId());
		dto.setUserId(user.getUserId());
		dto.setEmail(user.getEmail());
		dto.setPhone(user.getPhone());
		dto.setUserName(user.getPhone());
		ResponseStructure<UsersResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(dto);
		return new ResponseEntity<ResponseStructure<UsersResponseDto>>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserName(String username) {

		Users users = iUsersDao.userDetailsByUserName(username);

		if (users == null) {
			throw new DataNotFoundException("User not found with username: " + username);
		}

		UsersResponseDto dto = new UsersResponseDto();
		dto.setUserId(users.getUserId());
		dto.setUserName(users.getUserName());
		dto.setEmail(users.getEmail());
		dto.setPhone(users.getPhone());
		dto.setAddressId(users.getAddress().getAddressId());

		ResponseStructure<UsersResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(dto);

		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesForUserId(int userId) {

		List<Integer> ticketIds = paymentRepository.findTicketIdsByUserId(userId);

		if (ticketIds == null) {
			throw new DataNotFoundException("no tickets found");
		}

		List<Integer> showIds = ticketRepository.findShowIdsByTicketIds(ticketIds);

		if (showIds == null) {
			throw new DataNotFoundException("no shows found");
		}

		List<Integer> movieIds = movieShowRepository.findMovieIdsByShowIds(showIds);

		if (movieIds == null) {
			throw new DataNotFoundException("no movies found");
		}

		List<Movie> mdt = movieRepository.findAllById(movieIds);

		List<MovieResponseDto> m = mdt.stream().map(data -> {
			MovieResponseDto dto = new MovieResponseDto();
			dto.setMovieId(data.getMovieId());
			dto.setMovieName(data.getMovieName());
			dto.setTicketBasePrice(data.getTicketBasePrice()); // Ensure this is correctly mapped from your entity

			return dto;
		}).collect(Collectors.toList());

		ResponseStructure<List<MovieResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Successfully fetched all the movies for which user bought tickets");
		response.setData(m); 

		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<UsersResponseDto>> userDetailsByUserId(int userId) {
		Users user = iUsersDao.userDetailsByUserId(userId); 

		if (user == null) {
			
			throw new DataNotFoundException("User Not found for this Id: " + userId);
		} else {
			
			UsersResponseDto usersResponseDto = new UsersResponseDto();
			usersResponseDto.setUserId(user.getUserId());
			usersResponseDto.setUserName(user.getUserName());
			usersResponseDto.setEmail(user.getEmail());
			usersResponseDto.setPhone(user.getPhone());

			ResponseStructure<UsersResponseDto> response = new ResponseStructure<>();
			response.setStatusCode(HttpStatus.OK.value());
			response.setMessage("Success");
			response.setData(usersResponseDto);

	        return new ResponseEntity<>(response, HttpStatus.OK);  // Return response with status OK
	    }
	}	
	
//	@Override
//	public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findUsersByPhoneStartingWith(String phonePrefix) {
//		List<Users> users = iUsersDao.findByUserNameStartingWith(phonePrefix);
//		List<UsersResponseDto> userResponseDtos = users.stream().map(user -> {
//			UsersResponseDto dto = new UsersResponseDto();
////   		dto.setAddressId(user.getAddressId());
//			dto.setEmail(user.getEmail());
//			dto.setPhone(user.getPhone());
//			dto.setUserId(user.getUserId());
//			dto.setUserName(user.getUserName());
//			return dto;
//		}).collect(Collectors.toList());
//		ResponseStructure<List<UsersResponseDto>> responseStructure = new ResponseStructure<>();
//		responseStructure.setStatusCode(HttpStatus.OK.value());
//		responseStructure.setMessage("User fetched successfully");
//		responseStructure.setData(userResponseDtos);
//		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
//	}

	@Override
	public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findByUserNameStartingWith(String namePrefix) {
		List<Users> users = iUsersDao.findByUserNameStartingWith(namePrefix);
		List<UsersResponseDto> userResponseDtos = users.stream().map(user -> {
			UsersResponseDto dto = new UsersResponseDto();
     		dto.setAddressId(user.getAddress().getAddressId());
			dto.setEmail(user.getEmail());
			dto.setPhone(user.getPhone());
			dto.setUserId(user.getUserId());
			dto.setUserName(user.getUserName());
			return dto;
		}).collect(Collectors.toList());
		ResponseStructure<List<UsersResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("User fetched successfully");
		responseStructure.setData(userResponseDtos);
		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}

	
	public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findUsersByPhoneStartingWith(String phonePrefix) {
	    System.out.println("Searching for phone prefix: " + phonePrefix); 
	    List<Users> users = iUsersDao.findUsersByPhoneStartingWith(phonePrefix);
	    System.out.println("Found users: " + users.size());
	    List<UsersResponseDto> userResponseDtos = new ArrayList<>();
	    for (Users user : users) {
	        UsersResponseDto dto = new UsersResponseDto();
	        dto.setEmail(user.getEmail());
	        dto.setPhone(user.getPhone());
	        dto.setUserId(user.getUserId());
	        dto.setUserName(user.getUserName());
	        userResponseDtos.add(dto);
	    }
	    ResponseStructure<List<UsersResponseDto>> responseStructure = new ResponseStructure<>();
	    responseStructure.setStatusCode(HttpStatus.OK.value());
	    responseStructure.setMessage("Users fetched successfully by phone prefix");
	    responseStructure.setData(userResponseDtos);
	    return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}

	 @Override
	    public ResponseEntity<ResponseStructure<List<UsersResponseDto>>> findByUserIdGreaterThan(int userId) {
	        List<Users> users = iUsersDao.findByUserIdGreaterThan(userId);
	        
		    List<UsersResponseDto> userResponseDtos = new ArrayList<>();
		    for (Users user : users) {
		        UsersResponseDto dto = new UsersResponseDto();
		        dto.setAddressId(user.getAddress().getAddressId());
		        dto.setEmail(user.getEmail());
		        dto.setPhone(user.getPhone());
		        dto.setUserId(user.getUserId());
		        dto.setUserName(user.getUserName());
		        userResponseDtos.add(dto);
		    }
	        ResponseStructure<List<UsersResponseDto>> responseStructure = new ResponseStructure<>();
	        responseStructure.setStatusCode(HttpStatus.OK.value());
		    responseStructure.setMessage("Users fetched successfully");
		    responseStructure.setData(userResponseDtos);
		    return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	    }
	

} 
	
