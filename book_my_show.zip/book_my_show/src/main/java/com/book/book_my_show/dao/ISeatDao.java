package com.book.book_my_show.dao;

import java.util.List;

import com.book.book_my_show.model.entity.Seat;

public interface ISeatDao {
	public Seat seatById(int seatId);
	public Seat saveSeat(Seat seat);
	public Seat getSeatById(int seatId);
	public List<Seat> findSeatsBySeatNumber(String seatNumber);

}
