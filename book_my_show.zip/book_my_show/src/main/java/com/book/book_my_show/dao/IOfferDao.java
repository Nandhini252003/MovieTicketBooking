package com.book.book_my_show.dao;

public interface IOfferDao {

}
