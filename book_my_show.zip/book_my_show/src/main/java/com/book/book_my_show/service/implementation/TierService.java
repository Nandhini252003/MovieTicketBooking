package com.book.book_my_show.service.implementation;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.ITheatreDao;
import com.book.book_my_show.dao.ITierDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.model.requestDto.TierRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.model.responseDto.TierResponseDto;
import com.book.book_my_show.service.ITheatreService;
import com.book.book_my_show.service.ITierService;

@Service
public class TierService implements ITierService {

	@Autowired
	private ITierDao iTierDao;
	@Autowired
	private ITheatreDao iTheatreDao;

	@Override
	public ResponseEntity<ResponseStructure<List<TierResponseDto>>> getAllTiers(int id) {
		List<Tier> tiers = iTierDao.findTiersByTheatreId(id);
		List<TierResponseDto> tierData = tiers.stream().map(data -> {
			TierResponseDto tierResponseDto = new TierResponseDto();
			tierResponseDto.setTierId(data.getTierId());
			tierResponseDto.setTierName(data.getTierName());
			tierResponseDto.setTicketPriceMultiplier(data.getTicketPriceMultiplier());
			TheatreResponseDto theatreResponseDto = new TheatreResponseDto();
			if (data.getTheatre() != null) {
				theatreResponseDto.setTheatreId(data.getTheatre().getTheatreId());
			}
			tierResponseDto.setTheatreId(theatreResponseDto.getTheatreId());
			return tierResponseDto;
		}).collect(Collectors.toList());
		ResponseStructure<List<TierResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(tierData);
		return new ResponseEntity<ResponseStructure<List<TierResponseDto>>>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<TierResponseDto>> saveTier(TierRequestDto tierRequestDto) {

		Tier tier = new Tier();
		tier.setTierName(tierRequestDto.getTierName());
		Theatre theatre = iTheatreDao.findById(tierRequestDto.getTheatreId());
		if (theatre == null) {
			throw new DataNotFoundException("theatre not found with the given id");
		}
		tier.setTheatre(theatre);
		tier.setTicketPriceMultiplier(tierRequestDto.getTicketPriceMultiplier());
		Tier savedTier = iTierDao.saveTier(tier);

		TierResponseDto savedTierResponseDto = new TierResponseDto();
		savedTierResponseDto.setTierId(savedTier.getTierId());
		savedTierResponseDto.setTierName(savedTier.getTierName());
		savedTierResponseDto.setTicketPriceMultiplier(savedTier.getTicketPriceMultiplier());
		savedTierResponseDto.setTheatreId(savedTier.getTheatre().getTheatreId());

		ResponseStructure<TierResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Tier created successfully");
		response.setData(savedTierResponseDto);

		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	public ResponseEntity<ResponseStructure<List<TierResponseDto>>> updateTier(TierRequestDto tierDto, int theatre_id,
			int tier_id) {
		Tier tier = iTierDao.findTierById(tier_id);
		if (tier == null) {
			throw new DataNotFoundException("Tier with ID " + tier_id + " not found");
		}
		tier.setTierName(tierDto.getTierName());
		tier.setTicketPriceMultiplier(tierDto.getTicketPriceMultiplier());

		boolean theatreId = iTheatreDao.findTheatreId(theatre_id);
		if (theatreId && tierDto.getTheatreId() == theatre_id) {
			Theatre theatre = iTheatreDao.findById(theatre_id);
			tier.setTheatre(theatre);
		}

		Tier updatedTier = iTierDao.saveTier(tier);
		TierResponseDto tierResponseDto = new TierResponseDto();
		tierResponseDto.setTierId(updatedTier.getTierId());
		tierResponseDto.setTierName(updatedTier.getTierName());
		tierResponseDto.setTicketPriceMultiplier(updatedTier.getTicketPriceMultiplier());
		tierResponseDto.setTheatreId(updatedTier.getTheatre().getTheatreId());

		List<TierResponseDto> tierResponseDtos = List.of(tierResponseDto);

		ResponseStructure<List<TierResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Tier updated successfully");
		response.setData(tierResponseDtos);
		return new ResponseEntity<ResponseStructure<List<TierResponseDto>>>(response, HttpStatus.CREATED);
	}
}