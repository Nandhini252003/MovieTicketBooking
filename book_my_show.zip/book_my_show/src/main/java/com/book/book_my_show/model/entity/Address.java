package com.book.book_my_show.model.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "address")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "address_id")
	private int addressId;
	@NotNull(message = "Country cannot be null")
    @NotEmpty(message = "Country cannot be empty")
    @Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String country;
	@NotNull(message = "Country cannot be null")
    @NotEmpty(message = "Country cannot be empty")
    @Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String state;
	@NotNull(message = "Country cannot be null")
    @NotEmpty(message = "Country cannot be empty")
    @Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String city;
	@Column(name = "address_line")
	@NotNull(message = "Country cannot be null")
    @NotEmpty(message = "Country cannot be empty")
    @Size(min = 2, max = 100, message = "Country name should be between 2 and 100 characters")
	private String addressLine;
	@JsonIgnore
	@OneToMany(mappedBy = "address")
	private List<Theatre> theatres;
	@JsonIgnore
	@OneToMany(mappedBy = "address")
	private List<Users> users;

	public List<Users> getUsers() {
		return users;
	}

	public void setUsers(List<Users> users) {
		this.users = users;
	}

	public List<Theatre> getTheatres() {
		return theatres;
	}

	public void setTheatres(List<Theatre> theatres) {
		this.theatres = theatres;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

}
