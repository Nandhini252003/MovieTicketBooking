package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

public class TicketRequestDto {

    @NotNull(message = "Amount cannot be null")
    @Positive(message = "Amount must be a positive value")
    private int amount;

 
    private LocalDateTime purchaseDate;

    @NotNull(message = "Seat ID cannot be null")
    @Positive(message = "Seat ID must be a positive value")
    private int seatId;

    @NotNull(message = "Movie Show ID cannot be null")
    @Positive(message = "Movie Show ID must be a positive value")
    private int movieShowId;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public LocalDateTime getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDateTime purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public int getSeatId() {
        return seatId;
    }

    public void setSeatId(int seatId) {
        this.seatId = seatId;
    }

    public int getMovieShowId() {
        return movieShowId;
    }

    public void setMovieShowId(int movieShowId) {
        this.movieShowId = movieShowId;
    }
}
