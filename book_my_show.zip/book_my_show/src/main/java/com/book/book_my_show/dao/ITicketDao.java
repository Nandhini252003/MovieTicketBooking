package com.book.book_my_show.dao;

import java.util.List;

import com.book.book_my_show.model.entity.Ticket;
import com.book.book_my_show.model.responseDto.TicketResponseDto;

public interface ITicketDao {
	
	public List<Ticket> getAllTickets();
	public Ticket addNewTicket(Ticket ticket);
	public boolean findTicketId(int ticketId);
	public Ticket findTicketById(int ticketId);
	public Ticket getTicketById(int ticketId);
	public List<TicketResponseDto> findByMovieShow_Theatre_TheatreId(int theatreId);
	public int countTicketsByTheatreId(int theatreId);
	public Ticket findTicketBySeatAndMovieShow(int seatId, int showId);
}
