package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.ISeatDao;

import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Seat;

import com.book.book_my_show.repository.SeatRepository;

@Repository
public class SeatDao implements ISeatDao {
	@Autowired
	private SeatRepository seatRepository;

	@Override
	public Seat seatById(int seatId) {
		Optional<Seat> seat = seatRepository.findById(seatId);
		if (seat.isPresent())
			return seat.get();
		else
			throw new DataNotFoundException("seat with the given id doesnot present");
	}
	public Seat getSeatById(int seatId) {
		Optional<Seat> optSeat = seatRepository.findById(seatId);
		if(optSeat.isEmpty()) {
			throw new DataNotFoundException("no seat found with the given id:"+seatId);
		}
		return optSeat.get();
	}

	@Override
	public Seat saveSeat(Seat seat) {

		return seatRepository.save(seat);
	}
	@Override
    public List<Seat> findSeatsBySeatNumber(String seatNumber) {
        return seatRepository.findBySeatNumber(seatNumber);
    }
}
