package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.ITierDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.repository.TierRepository;

@Repository
public class TierDao implements ITierDao {
	@Autowired
	private TierRepository tierRepository;

	@Override
	public List<Tier> findTiersByTheatreId(int id) {
		List<Tier> tiers = tierRepository.findTierByTheatreId(id);
		if (tiers.isEmpty()) {
			throw new DataNotFoundException("Data Not Found.");
		} else {
			return tiers;
		}
	}



	@Override
	public Tier getTierById(int tierId) {
		Optional<Tier> optTier = tierRepository.findById(tierId);
		if(optTier.isEmpty()) {
			throw new DataNotFoundException("no tier found with the given id:"+tierId);
		}
		return optTier.get();
	}

	public Boolean findTierId(int tierId) {
		return tierRepository.existsById(tierId);
	}

	@Override
	public Tier findTierById(int tierId) {
		return tierRepository.findById(tierId).get();
	}

	@Override
	public Tier saveTier(Tier tier) {
		return tierRepository.save(tier);
	}
}