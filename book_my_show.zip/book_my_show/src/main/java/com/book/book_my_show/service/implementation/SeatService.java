package com.book.book_my_show.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.book.book_my_show.dao.ISeatDao;
import com.book.book_my_show.dao.ITierDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Seat;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.model.requestDto.SeatRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.SeatResponseDto;
import com.book.book_my_show.service.ISeatService;

@Service
public class SeatService implements ISeatService{
	@Autowired
	private ISeatDao iSeatDao;
	@Autowired
	private ITierDao iTierDao;

	@Override
	public ResponseEntity<ResponseStructure<SeatResponseDto>> getSeatById(int seatId) {
		Seat seat = iSeatDao.seatById(seatId);
		SeatResponseDto seatResponseDto= new SeatResponseDto();
		seatResponseDto.setSeatId(seat.getSeatId());
		seatResponseDto.setTierId(seat.getSeatId());
		seatResponseDto.setSeatNumber(seat.getSeatNumber());
		
		ResponseStructure<SeatResponseDto> response = new ResponseStructure<>();
		response.setMessage("Success");
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setData(seatResponseDto);

		return new ResponseEntity<ResponseStructure<SeatResponseDto>>(response, HttpStatus.FOUND);
	}	
	@Override
	public ResponseEntity<ResponseStructure<SeatResponseDto>> updateSeatBySeatIdTierId(int seatId, int tierId,
			SeatRequestDto seatRequestDto) {
		Seat seat = iSeatDao.getSeatById(seatId);
		Tier tier = iTierDao.getTierById(tierId);
		if(seat==null) {
			throw new DataNotFoundException("no seat exists with the given id");
		}
		else if(tier==null) {
			throw new DataNotFoundException("no tier exists with the given id");
		}
		else if(seat.getTier().getTierId()!=tierId) {
			throw new DataNotFoundException("Give SeatId does not belong to the provided tier ID");
		}
		seat.setSeatNumber(seatRequestDto.getSeatNumber());
		Seat savedSeat = iSeatDao.saveSeat(seat);
		
		 SeatResponseDto savedseatResponseDto = new SeatResponseDto();
		    savedseatResponseDto.setSeatId(savedSeat.getSeatId());
		    savedseatResponseDto.setTierId(savedSeat.getTier().getTierId());
		    savedseatResponseDto.setSeatNumber(savedSeat.getSeatNumber());
		    
		    ResponseStructure<SeatResponseDto> response = new ResponseStructure<>();
		    response.setStatusCode(HttpStatus.CREATED.value()); 
		    response.setMessage("updated seat number successfully");
		    response.setData(savedseatResponseDto);		    
		    return new ResponseEntity<>(response, HttpStatus.CREATED);
	}    
	public ResponseEntity<ResponseStructure<SeatResponseDto>> AddSeatByTierId(SeatRequestDto seatDto, int tierId) {
		Boolean isTier = iTierDao.findTierId(tierId);
		if(isTier) {
			Seat seat=new Seat();
			seat.setSeatNumber(seatDto.getSeatNumber());
			Tier tier=iTierDao.findTierById(tierId);
			seat.setTier(tier);
			
			Seat savedSeat=iSeatDao.saveSeat(seat);
			
			SeatResponseDto seatResDto=new SeatResponseDto();
			seatResDto.setSeatId(savedSeat.getSeatId());
			seatResDto.setSeatNumber(savedSeat.getSeatNumber());
			seatResDto.setTierId(savedSeat.getTier().getTierId());
			ResponseStructure<SeatResponseDto> response=new ResponseStructure<>();
			response.setStatusCode(HttpStatus.CREATED.value());
			response.setMessage("Record created successfully");
			response.setData(seatResDto);
			return new ResponseEntity<ResponseStructure<SeatResponseDto>>(response,HttpStatus.CREATED);
		}
		else {
			throw new DataNotFoundException("Tier ID not found");
		}
	}
	@Override
	public ResponseEntity<ResponseStructure<List<SeatResponseDto>>> getSeatsBySeatNumber(String seatNumber) {
        List<Seat> seats = iSeatDao.findSeatsBySeatNumber(seatNumber);
        List<SeatResponseDto> seatResponseDtos = seats.stream()
                .map(seat -> new SeatResponseDto(
                        seat.getSeatId(),
                        seat.getSeatNumber(),
                        seat.getTier().getTierId()
                ))
                .collect(Collectors.toList());
        ResponseStructure<List<SeatResponseDto>> responseStructure = new ResponseStructure<>();

        if (seatResponseDtos.isEmpty()) {
            responseStructure.setStatusCode(HttpStatus.NO_CONTENT.value());
            responseStructure.setMessage("No seats found with seat number: " + seatNumber);
            responseStructure.setData(seatResponseDtos);
        } else {
            responseStructure.setStatusCode(HttpStatus.OK.value());
            responseStructure.setMessage("Seats fetched successfully");
            responseStructure.setData(seatResponseDtos);
        }

        return new ResponseEntity<>(responseStructure, HttpStatus.valueOf(responseStructure.getStatusCode()));
    }
	}

