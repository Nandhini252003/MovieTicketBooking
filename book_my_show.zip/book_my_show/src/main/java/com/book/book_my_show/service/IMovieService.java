package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;

import com.book.book_my_show.model.requestDto.MovieRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;

public interface IMovieService {
	ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getAllMovieDetails();
	MovieResponseDto getMovieByName(String movieName);
	
	ResponseEntity<ResponseStructure<MovieResponseDto>> UpdateMovieDetailsByMovieId(int movieId,
	MovieRequestDto movieRequestDto);
	ResponseEntity<ResponseStructure<MovieResponseDto>> getMovieById(int movieId);
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesByPrefix(String prefix);
	ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesWithTicketPriceLessThan(int price);
	ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesBySubstring(String substring);
	ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesByTicketPriceRange(int minPrice, int maxPrice);

}
