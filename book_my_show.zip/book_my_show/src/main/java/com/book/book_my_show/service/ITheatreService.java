package com.book.book_my_show.service;
import java.util.List;
import org.springframework.http.ResponseEntity;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.AddressRequestDto;
import com.book.book_my_show.model.requestDto.TheatreRequestDto;
import com.book.book_my_show.model.responseDto.AddressResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;


public interface ITheatreService {
//	TheatreResponseDto addNewTheatre(TheatreRequestDto theatreRequestDto);

	ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getTheatreByCity(String city);
	ResponseEntity<ResponseStructure<AddressResponseDto>> updateTheatre(int theatreId,
			AddressRequestDto addressRequestDto);


//	ResponseEntity<ResponseStructure<TheatreResponseDto>> updateTheatre(int theatreId,
//			TheatreRequestDto theatreRequestDto);

	ResponseEntity<ResponseStructure<TheatreResponseDto>> theatreDetailsByName(String theatreName);

	public ResponseStructure<List<TheatreResponseDto>> getAllTheatres();

	public ResponseEntity<ResponseStructure<Theatre>> findById(int theatreId);

	ResponseEntity<ResponseStructure<TheatreResponseDto>> saveTheatre(TheatreRequestDto theatreRequestDto);

	ResponseEntity<ResponseStructure<List<Theatre>>> getTheatresByCountry(String country);

	public ResponseEntity<ResponseStructure<AddressResponseDto>> getTheatreAddress(int theatreId);
	public ResponseEntity<ResponseStructure<Theatre>> getTheatreWithMaxCapacity();
	public ResponseEntity<ResponseStructure<List<String>>> getTheatresInAlphabeticalOrder();
	public ResponseEntity<ResponseStructure<List<TheatreResponseDto>>> getTheatresByCapacityRange(int minCapacity, int maxCapacity);
	public ResponseStructure<List<TheatreResponseDto>> getTheatresByScreenType(String screenType);
}
