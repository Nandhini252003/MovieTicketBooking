package com.book.book_my_show.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.book.book_my_show.model.entity.Seat;

public interface SeatRepository  extends JpaRepository<Seat, Integer>{
	List<Seat> findBySeatNumber(String seatNumber);

}
