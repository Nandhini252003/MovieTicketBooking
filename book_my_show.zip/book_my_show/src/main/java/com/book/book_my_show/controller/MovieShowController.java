package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.MovieShowRequestDto;
import com.book.book_my_show.model.responseDto.MovieShowResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.IMovieShowService;

import jakarta.validation.Valid;

@RequestMapping("/api/shows")
@RestController
public class MovieShowController {

	@Autowired
	private IMovieShowService iMovieShowService;

	// Search movie shows by movie name, screen type, and city
	@GetMapping("/search/{movieName}/{screen}/{city}")
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> searchMovieShows(
			@PathVariable String movieName, @PathVariable String screen, @PathVariable String city) {
		return iMovieShowService.searchMovieShows(movieName, screen, city);
	}

	// Get movie show by ID
	@GetMapping("/{movieShowId}")
	public ResponseEntity<ResponseStructure<MovieShowResponseDto>> getMovieShowById(@PathVariable int movieShowId) {
		return iMovieShowService.getMovieShowById(movieShowId);
	}

	// Get movie shows by movie name and city
	@GetMapping("/movieShows/{movieName}/city/{city}")
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowsByMovieNameAndCity(
			@PathVariable String movieName, @PathVariable String city) {
		return iMovieShowService.getMovieShowsByMovieNameAndCity(movieName, city);
	}

	// Save a movie show
	@PostMapping("/savingMovie")
	public ResponseEntity<ResponseStructure<MovieShowResponseDto>> saveMovieShow(
			@RequestBody @Valid MovieShowRequestDto movieShowRequestDto) {
		return iMovieShowService.saveMovieShow(movieShowRequestDto);
	}

	// Get movie shows by movie name
	@GetMapping("/movie/{movieName}")
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowByMovieName(
			@PathVariable String movieName) {
		return iMovieShowService.getMovieShowByMovieName(movieName);
	}

	// Get all movie shows
	@GetMapping
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getAllMovieShows() {
		return iMovieShowService.getAllMovieShows();
	}

	// Get movie shows by theatre name
	@GetMapping("/theatre/{theatrename}")
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowsByTheatreName(
			@PathVariable String theatrename) {
		return iMovieShowService.getMovieShowsByTheatreName(theatrename);
	}
}
