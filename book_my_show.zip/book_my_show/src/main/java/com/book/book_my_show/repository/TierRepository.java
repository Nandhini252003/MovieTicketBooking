package com.book.book_my_show.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.model.responseDto.TierResponseDto;

public interface TierRepository extends JpaRepository<Tier, Integer> {

	 @Query("SELECT t FROM Tier t WHERE t.theatre.theatreId = :theatreId")
	    List<Tier> findTierByTheatreId(@Param("theatreId") int theatreId);
	    List<Tier> findByTierName(String type);
	    List<Tier> findByTicketPriceMultiplier(int ticketPriceMultiplier);
}
