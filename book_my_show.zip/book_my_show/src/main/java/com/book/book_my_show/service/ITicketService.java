package com.book.book_my_show.service;

import java.util.List;
import org.springframework.http.ResponseEntity;

import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.TicketRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.model.responseDto.TicketResponseDto;

public interface ITicketService {
	List<TicketResponseDto> getAllTickets();
	ResponseEntity<ResponseStructure<TicketResponseDto>> addTicket(TicketRequestDto ticketRequestDto);
	ResponseEntity<ResponseStructure<TicketResponseDto>> getTicketById(int ticketId);
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> getTheatreWithMaxTicketsSold();
}
