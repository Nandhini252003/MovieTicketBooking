package com.book.book_my_show.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.book.book_my_show.model.entity.Ticket;
import com.book.book_my_show.model.responseDto.TicketResponseDto;

public interface TicketRepository  extends JpaRepository<Ticket, Integer>{

	@Query("SELECT t.movieShow.showId FROM Ticket t WHERE t.ticketId IN :ticketIds")
	List<Integer> findShowIdsByTicketIds(List<Integer> ticketIds);

	List<TicketResponseDto> findByMovieShow_Theatre_TheatreId(int theatreId);
	
	@Query("SELECT COUNT(t) FROM Ticket t WHERE t.movieShow.theatre.theatreId = :theatreId")
	int countTicketsByTheatreId(int theatreId);

	 @Query("SELECT t FROM Ticket t WHERE t.seat.seatId = :seatId AND t.movieShow.showId = :showId")
	Ticket findTicketBySeatAndMovieShow(int seatId, int showId);
}
