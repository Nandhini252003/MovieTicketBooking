package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;

public class OfferRequestDto {

    @NotNull(message = "Movie Show ID cannot be null")
    @Min(value = 1, message = "Movie Show ID should be greater than or equal to 1")
    private int movieShowId;

    @NotEmpty(message = "Offer Details cannot be empty")
    private String offerDetails;

    public int getMovieShowId() {
        return movieShowId;
    }

    public void setMovieShow(int movieShowId) {
        this.movieShowId = movieShowId;
    }

    public String getOfferDetails() {
        return offerDetails;
    }

    public void setOfferDetails(String offerDetails) {
        this.offerDetails = offerDetails;
    }
}
