package com.book.book_my_show.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.book.book_my_show.model.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Integer> {

    List<Address> findByCity(String city); 
	List<Address> findByState(String state);

}
