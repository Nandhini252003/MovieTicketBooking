package com.book.book_my_show.service.implementation;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IPaymentDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Payment;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.entity.Ticket;
import com.book.book_my_show.dao.ITicketDao;
import com.book.book_my_show.dao.IUsersDao;
import com.book.book_my_show.model.entity.Tier;
import com.book.book_my_show.model.entity.Users;
import com.book.book_my_show.model.requestDto.PaymentRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.PaymentResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.repository.TicketRepository;
import com.book.book_my_show.repository.UsersRepository;
import com.book.book_my_show.model.responseDto.TicketResponseDto;
import com.book.book_my_show.model.responseDto.TierResponseDto;
import com.book.book_my_show.model.responseDto.UsersResponseDto;
import com.book.book_my_show.service.IPaymentService;

@Service
public class PaymentService implements IPaymentService {
	@Autowired
	private IPaymentDao iPaymentDao;


	@Override
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentDetailsByUserId(int userId) {

		List<Payment> payment = iPaymentDao.getPaymentDetailsByUserId(userId);
		List<PaymentResponseDto> paymentResponseDtos = payment.stream()
				.map(paymentResponseDto -> new PaymentResponseDto(paymentResponseDto.getPaymentId(),
						paymentResponseDto.getAmount(), paymentResponseDto.getPaymentDate(),
						paymentResponseDto.getPaymentStatus(), paymentResponseDto.getTicket().getTicketId(),
						paymentResponseDto.getUser().getUserId()))
				.collect(Collectors.toList());

		if (!paymentResponseDtos.isEmpty()) {
			ResponseStructure<List<PaymentResponseDto>> response = new ResponseStructure<>();
			response.setData(paymentResponseDtos);
			response.setMessage("Payment Details found");
			response.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<>(response, HttpStatus.FOUND);
		} else {
			throw new DataNotFoundException("Payment Details doesn't Exist for this userId: " + userId);
		}
	}

	@Autowired
	private ITicketDao iTicketDao;
	@Autowired
	private IUsersDao iUsersDao;

	@Override
	public ResponseEntity<ResponseStructure<PaymentResponseDto>> getPaymentById(int paymentId) {

		Payment payments = iPaymentDao.getPaymentById(paymentId);
		PaymentResponseDto paymentResponseDto = new PaymentResponseDto();
		paymentResponseDto.setPaymentId(payments.getPaymentId());
		paymentResponseDto.setPaymentDate(payments.getPaymentDate());
		paymentResponseDto.setPaymentStatus(payments.getPaymentStatus());
		paymentResponseDto.setAmount(payments.getAmount());
		paymentResponseDto.setTicketId(payments.getTicket().getTicketId());
		paymentResponseDto.setUserId(payments.getUser().getUserId());

		ResponseStructure<PaymentResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Succesfull");
		response.setData(paymentResponseDto);

		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getAllPayments() {
		List<Payment> payments = iPaymentDao.getAllPayments();
		List<PaymentResponseDto> paymentResponseDtos = payments.stream().map(data -> {
			UsersResponseDto usersResponseDto = new UsersResponseDto();
			if (data.getUser() != null) {
				usersResponseDto.setUserId(data.getUser().getUserId());
				usersResponseDto.setUserName(data.getUser().getUserName());
			}
			TicketResponseDto ticketResponseDto = new TicketResponseDto();
			if (data.getTicket() != null) {
				ticketResponseDto.setTicketId(data.getTicket().getTicketId());
				ticketResponseDto.setPurchaseDate(data.getTicket().getPurchaseDate());
			}

			PaymentResponseDto paymentResponseDto = new PaymentResponseDto();
			paymentResponseDto.setPaymentId(data.getPaymentId());
			paymentResponseDto.setAmount(data.getAmount());
			paymentResponseDto.setPaymentDate(data.getPaymentDate());
			paymentResponseDto.setPaymentStatus(data.getPaymentStatus());
			paymentResponseDto.setTicketId(data.getTicket().getTicketId());
			paymentResponseDto.setUserId(data.getUser().getUserId());
			return paymentResponseDto;
		}).collect(Collectors.toList());
		ResponseStructure<List<PaymentResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Success");
		responseStructure.setData(paymentResponseDtos);
		return new ResponseEntity<ResponseStructure<List<PaymentResponseDto>>>(responseStructure, HttpStatus.FOUND);

	}

	@Override
	public ResponseEntity<ResponseStructure<PaymentResponseDto>> addPayment(PaymentRequestDto paymentRequestDto) {
		if (paymentRequestDto.getTicketId() <= 0) {
			throw new DataNotFoundException("Invalid ticket ID: " + paymentRequestDto.getTicketId());
		}
		if (paymentRequestDto.getUserId() <= 0) {
			throw new DataNotFoundException("Invalid user ID: " + paymentRequestDto.getUserId());
		}
		Payment payment = new Payment();
		payment.setAmount(paymentRequestDto.getAmount());
		payment.setPaymentDate(paymentRequestDto.getPaymentDate());
		payment.setPaymentStatus(paymentRequestDto.getPaymentStatus());

		Ticket ticket = iTicketDao.findTicketById(paymentRequestDto.getTicketId());
		if (ticket == null) {
			throw new DataNotFoundException("Ticket with ID " + paymentRequestDto.getTicketId() + " not found.");
		}
		payment.setTicket(ticket);

		Users user = iUsersDao.getUserById(paymentRequestDto.getUserId());
		if (user == null) {
			throw new DataNotFoundException("User with ID " + paymentRequestDto.getUserId() + " not found.");
		}
		payment.setUser(user);
		Payment savedPayment = iPaymentDao.addPayment(payment);
		PaymentResponseDto dto = new PaymentResponseDto();
		dto.setPaymentId(savedPayment.getPaymentId());
		dto.setAmount(savedPayment.getAmount());
		dto.setPaymentDate(savedPayment.getPaymentDate());
		dto.setPaymentStatus(savedPayment.getPaymentStatus());
		dto.setTicketId(savedPayment.getTicket().getTicketId());
		dto.setUserId(savedPayment.getUser().getUserId());
		ResponseStructure<PaymentResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Payment record created successfully.");
		response.setData(dto);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentByStatus(String paymentStatus) {
		List<Payment> payments = iPaymentDao.getPaymentsByStatus(paymentStatus);
		List<PaymentResponseDto> dtos = payments.stream().map(data -> {
			PaymentResponseDto dto = new PaymentResponseDto();
			dto.setPaymentId(data.getPaymentId());
			dto.setAmount(data.getAmount());
			dto.setPaymentStatus(data.getPaymentStatus());
			dto.setPaymentDate(data.getPaymentDate());
			dto.setTicketId(data.getTicket().getTicketId());
			dto.setUserId(data.getUser().getUserId());
			return dto;
		}).collect(Collectors.toList());
		ResponseStructure<List<PaymentResponseDto>> response = new ResponseStructure<>();
		response.setMessage("success");
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setData(dtos);
		return new ResponseEntity<ResponseStructure<List<PaymentResponseDto>>>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<PaymentResponseDto>>> getPaymentsByUserId(int userId) {
		List<Payment> payments = iPaymentDao.getPaymentsByUserId(userId);

		List<PaymentResponseDto> prd = payments.stream().map(data -> {
			PaymentResponseDto payResponseDto = new PaymentResponseDto();
			payResponseDto.setPaymentId(data.getPaymentId());
			payResponseDto.setTicketId(data.getTicket().getTicketId());
			payResponseDto.setAmount(data.getAmount());
			payResponseDto.setPaymentDate(data.getPaymentDate());
			payResponseDto.setPaymentStatus(data.getPaymentStatus());
			payResponseDto.setUserId(data.getUser().getUserId());
			return payResponseDto;
		}).collect(Collectors.toList());

		ResponseStructure<List<PaymentResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Succesfully fet hed payment details of userid:" + userId);
		response.setData(prd);

		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

}
