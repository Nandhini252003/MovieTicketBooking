package com.book.book_my_show.exception;

public class DataAlreadyExistsException extends RuntimeException {
	public DataAlreadyExistsException(String msg) {
		super(msg);
	}

}
