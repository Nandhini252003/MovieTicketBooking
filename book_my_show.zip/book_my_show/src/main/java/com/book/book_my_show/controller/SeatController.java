package com.book.book_my_show.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.book.book_my_show.model.requestDto.SeatRequestDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.SeatResponseDto;
import com.book.book_my_show.service.ISeatService;

import jakarta.validation.Valid;

@RequestMapping("/api/seats")
@RestController
public class SeatController {

	@Autowired
	private ISeatService iSeatService;

	@GetMapping("/{seatId}")
	public ResponseEntity<ResponseStructure<SeatResponseDto>> getSeatById(@PathVariable int seatId) {
		return iSeatService.getSeatById(seatId);
	}

	@PutMapping("/update/{seatId}/{tierId}")
	public ResponseEntity<ResponseStructure<SeatResponseDto>> updateSeatBySeatIdTierId(@PathVariable int seatId,
			@PathVariable int tierId, @RequestBody @Valid SeatRequestDto seatRequestDto, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			ResponseStructure<SeatResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
		}
		return iSeatService.updateSeatBySeatIdTierId(seatId, tierId, seatRequestDto);
	}

	@PostMapping("/{tierId}")
	public ResponseEntity<ResponseStructure<SeatResponseDto>> addSeat(@RequestBody @Valid SeatRequestDto seat,
			@PathVariable int tierId, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			ResponseStructure<SeatResponseDto> responseStructure = new ResponseStructure<>();
			responseStructure.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseStructure.setMessage("Validation failed " + bindingResult.getAllErrors());
			responseStructure.setData(null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseStructure);
		}
		return iSeatService.AddSeatByTierId(seat, tierId);
	}

	@GetMapping("/searchBySeatNumber")
	public ResponseEntity<ResponseStructure<List<SeatResponseDto>>> searchSeatsBySeatNumber(
			@RequestParam String seatNumber) {
		return iSeatService.getSeatsBySeatNumber(seatNumber);
	}
}
