package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class TierRequestDto {

    @NotEmpty(message = "Tier name cannot be empty")
    private String tierName;

    @NotNull(message = "Theatre ID cannot be null")
    @Positive(message = "Theatre ID must be a positive value")
    private int theatreId;

    @NotNull(message = "Ticket price multiplier cannot be null")
    @Positive(message = "Ticket price multiplier must be a positive value")
    private int ticketPriceMultiplier;

    public String getTierName() {
        return tierName;
    }

    public void setTierName(String tierName) {
        this.tierName = tierName;
    }

    public int getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(int theatreId) {
        this.theatreId = theatreId;
    }

    public int getTicketPriceMultiplier() {
        return ticketPriceMultiplier;
    }

    public void setTicketPriceMultiplier(int ticketPriceMultiplier) {
        this.ticketPriceMultiplier = ticketPriceMultiplier;
    }

    public TierRequestDto() {}

    public TierRequestDto(String tierName, int theatreId, int ticketPriceMultiplier) {
        this.tierName = tierName;
        this.theatreId = theatreId;
        this.ticketPriceMultiplier = ticketPriceMultiplier;
    }
}
