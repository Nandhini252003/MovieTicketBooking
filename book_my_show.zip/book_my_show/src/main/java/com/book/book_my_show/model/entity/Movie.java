package com.book.book_my_show.model.entity;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "movie")
public class Movie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "movie_id")
	private int movieId;
	@Column(name = "movie_name")
	@NotNull(message = "Movie name cannot be null")
	@NotEmpty(message = "Movie name cannot be empty")
	@Size(min = 2, max = 100, message = "Movie name should be between 2 and 100 characters")
	private String movieName;
	@Column(name = "ticket_base_price")
	@NotNull(message = "Ticket base price cannot be null")
	@Min(value = 1, message = "Ticket base price should be at least 1")
	private int ticketBasePrice;

	public List<MovieShow> getMovieShows() {
		return movieShows;
	}

	public void setMovieShows(List<MovieShow> movieShows) {
		this.movieShows = movieShows;
	}

	@JsonIgnore
	@OneToMany(mappedBy = "movie")
	@JsonBackReference
	private List<MovieShow> movieShows;

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public int getTicketBasePrice() {
		return ticketBasePrice;
	}

	public void setTicketBasePrice(int ticketBasePrice) {
		this.ticketBasePrice = ticketBasePrice;
	}
//	@Override
//	public String toString() {
//		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", ticketBasePrice=" + ticketBasePrice
//				+ ", movieShows=" + movieShows + "]";
//	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", ticketBasePrice=" + ticketBasePrice + "]";
	}

}
