package com.book.book_my_show.service.implementation;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IMovieDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.model.requestDto.MovieRequestDto;
import com.book.book_my_show.model.responseDto.MovieResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.IMovieService;

@Service
public class MovieService implements IMovieService {
	@Autowired
	private IMovieDao iMovieDao;

	@Override
	public MovieResponseDto getMovieByName(String movieName) {
		Movie movie = iMovieDao.getMovieByName(movieName);
		MovieResponseDto movieResponseDto = new MovieResponseDto();
		movieResponseDto.setMovieId(movie.getMovieId());
		movieResponseDto.setMovieName(movie.getMovieName());
		movieResponseDto.setTicketBasePrice(movie.getTicketBasePrice());
		return movieResponseDto;
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getAllMovieDetails() {
		List<Movie> movies = iMovieDao.getMovieDetails();
		List<MovieResponseDto> mdtos = movies.stream().map(data -> {
			MovieResponseDto mrdtos = new MovieResponseDto();
			mrdtos.setMovieId(data.getMovieId());
			mrdtos.setMovieName(data.getMovieName());
			mrdtos.setTicketBasePrice(data.getTicketBasePrice());
			return mrdtos;
		}).collect(Collectors.toList());
		ResponseStructure<List<MovieResponseDto>> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(mdtos);
		return new ResponseEntity<ResponseStructure<List<MovieResponseDto>>>(response, HttpStatus.FOUND);
	}

	
	@Override
	public ResponseEntity<ResponseStructure<MovieResponseDto>> UpdateMovieDetailsByMovieId(int movieId,
		MovieRequestDto movieRequestDto) {
		Movie movie = iMovieDao.getMovieByMovieId(movieId);
		if(movie == null){
			throw new DataNotFoundException("NOT FOUND");	
		}
//		System.out.println("Updating movie: " + movieRequestDto.getMovieName() + ", " + movieRequestDto.getTicketBasePrice());
		
		movie.setMovieName(movieRequestDto.getMovieName());
		movie.setTicketBasePrice(movieRequestDto.getTicketBasePrice());	
		
		Movie savedMovie = iMovieDao.saveMovie(movie);
		
		MovieResponseDto movieResponseDto = new MovieResponseDto();		
	    movieResponseDto.setMovieId(savedMovie.getMovieId());
	    movieResponseDto.setMovieName(savedMovie.getMovieName());
	    movieResponseDto.setTicketBasePrice(savedMovie.getTicketBasePrice());
	    
		ResponseStructure<MovieResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setMessage("Success");
		response.setData(movieResponseDto);
		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}
	


	@Override
	public ResponseEntity<ResponseStructure<MovieResponseDto>> getMovieById(int movieId) {
		Movie movie = iMovieDao.getMovieById(movieId);
		MovieResponseDto movieResponseDto = new MovieResponseDto();
		movieResponseDto.setMovieId(movie.getMovieId());
		movieResponseDto.setMovieName(movie.getMovieName());
		movieResponseDto.setTicketBasePrice(movie.getTicketBasePrice());
		ResponseStructure<MovieResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("success");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(movieResponseDto);
		return new ResponseEntity<>(responseStructure, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesByPrefix(String prefix) {
		List<Movie> movies = iMovieDao.getMoviesByPrefix(prefix);
		List<MovieResponseDto> movieResponseDtos = movies.stream().map(movie -> {
			MovieResponseDto dto = new MovieResponseDto();
			dto.setMovieId(movie.getMovieId());
			dto.setMovieName(movie.getMovieName());
			dto.setTicketBasePrice(movie.getTicketBasePrice());
			return dto;
		}).collect(Collectors.toList());
		ResponseStructure<List<MovieResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Movies fetched successfully");
		responseStructure.setData(movieResponseDtos);
		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesWithTicketPriceLessThan(int price) {
		List<Movie> movies = iMovieDao.getMoviesWithTicketPriceLessThan(price);
        List<MovieResponseDto> movieResponseDtos = movies.stream()
                .map(movie -> new MovieResponseDto(
                        movie.getMovieId(),
                        movie.getMovieName(),
                        movie.getTicketBasePrice()
                ))
                .collect(Collectors.toList());

        ResponseStructure<List<MovieResponseDto>> responseStructure = new ResponseStructure<>();
        if (movieResponseDtos.isEmpty()) {
            responseStructure.setStatusCode(HttpStatus.NO_CONTENT.value());
            responseStructure.setMessage("No movies found with ticket price less than " + price);
            responseStructure.setData(movieResponseDtos);
        } else {
            responseStructure.setStatusCode(HttpStatus.OK.value());
            responseStructure.setMessage("Movies fetched successfully");
            responseStructure.setData(movieResponseDtos);
        }

        return new ResponseEntity<>(responseStructure, HttpStatus.valueOf(responseStructure.getStatusCode()));
    }

	@Override
    public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesBySubstring(String substring) {
        List<Movie> movies = iMovieDao.findByMovieNameContaining(substring);
        List<MovieResponseDto> movieResponseDtos = movies.stream()
                .map(movie -> new MovieResponseDto(
                        movie.getMovieId(),
                        movie.getMovieName(),
                        movie.getTicketBasePrice()
                ))
                .collect(Collectors.toList());
        ResponseStructure<List<MovieResponseDto>> responseStructure = new ResponseStructure<>();

        if (movieResponseDtos.isEmpty()) {
            responseStructure.setStatusCode(HttpStatus.NO_CONTENT.value());
            responseStructure.setMessage("No movies found containing the substring: " + substring);
            responseStructure.setData(movieResponseDtos);
        } else {
            responseStructure.setStatusCode(HttpStatus.OK.value());
            responseStructure.setMessage("Movies fetched successfully");
            responseStructure.setData(movieResponseDtos);
        }

        return new ResponseEntity<>(responseStructure, HttpStatus.valueOf(responseStructure.getStatusCode()));
    }
	@Override
    public ResponseEntity<ResponseStructure<List<MovieResponseDto>>> getMoviesByTicketPriceRange(int minPrice, int maxPrice) {
        // Fetch movies from the DAO
        List<Movie> movies = iMovieDao.findMoviesByTicketPriceBetween(minPrice, maxPrice);

        // Convert movie entities to response DTOs
        List<MovieResponseDto> movieResponseDtos = movies.stream()
                .map(movie -> new MovieResponseDto(
                        movie.getMovieId(),
                        movie.getMovieName(),
                        movie.getTicketBasePrice()
                ))
                .collect(Collectors.toList());

        // Prepare ResponseStructure
        ResponseStructure<List<MovieResponseDto>> responseStructure = new ResponseStructure<>();

        if (movieResponseDtos.isEmpty()) {
            responseStructure.setStatusCode(HttpStatus.NO_CONTENT.value());
            responseStructure.setMessage("No movies found in the price range: " + minPrice + " - " + maxPrice);
            responseStructure.setData(movieResponseDtos);
        } else {
            responseStructure.setStatusCode(HttpStatus.OK.value());
            responseStructure.setMessage("Movies fetched successfully");
            responseStructure.setData(movieResponseDtos);
        }

        return new ResponseEntity<>(responseStructure, HttpStatus.valueOf(responseStructure.getStatusCode()));
    }
	

}
