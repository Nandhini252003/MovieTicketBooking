package com.book.book_my_show.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "payments")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_id")
	private int paymentId;
	@NotNull(message = "Amount cannot be null")
	@Positive(message = "Amount must be a positive value")
	private int amount;
//  @NotEmpty(message = "Payment Date cannot be empty")
//  @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Payment Date must be in the format yyyy-MM-dd")
	@Column(name = "payment_date")
	private String paymentDate;
	@NotEmpty(message = "Payment Status cannot be empty")
	@Column(name = "payment_status")
	private String paymentStatus;
	@ManyToOne
	@JoinColumn(name = "ticket_id")
	@NotNull(message = "Ticket ID cannot be null")
	@Positive(message = "Ticket ID must be a positive value")
	private Ticket ticket;
	@ManyToOne
	@JoinColumn(name = "user_id")
	@NotNull(message = "User ID cannot be null")
	@Positive(message = "User ID must be a positive value")
	private Users user;

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", amount=" + amount + ", paymentDate=" + paymentDate
				+ ", paymentStatus=" + paymentStatus + ", ticket=" + ticket + ", user=" + user + "]";
	}
}
