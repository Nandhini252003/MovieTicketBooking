package com.book.book_my_show.model.requestDto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
//import jakarta.validation.constraints.Pattern;

public class PaymentRequestDto {

	@NotNull(message = "Amount cannot be null")
	@Positive(message = "Amount must be a positive value")
	private int amount;

//    @NotEmpty(message = "Payment Date cannot be empty")
//    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Payment Date must be in the format yyyy-MM-dd")
	private String paymentDate;

	@NotEmpty(message = "Payment Status cannot be empty")
	private String paymentStatus;

	@NotNull(message = "Ticket ID cannot be null")
	@Positive(message = "Ticket ID must be a positive value")
	private int ticketId;

	@NotNull(message = "User ID cannot be null")
	@Positive(message = "User ID must be a positive value")
	private int userId;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
}