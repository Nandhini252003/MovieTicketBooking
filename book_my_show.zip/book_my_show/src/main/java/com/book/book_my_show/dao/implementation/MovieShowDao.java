package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.IMovieShowDao;
import com.book.book_my_show.model.entity.MovieShow;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.repository.MovieRepository;
import com.book.book_my_show.repository.MovieShowRepository;

@Repository
public class MovieShowDao implements IMovieShowDao {

	@Autowired
	private MovieShowRepository movieShowRepository;
	@Autowired
	private MovieRepository movieRepository;
	@Override
	public List<MovieShow> getMovieShowByMovieName(String movieName) {
        return movieShowRepository.getMovieShowByMovieName(movieName);  
	}

	@Override
	public MovieShow movieShowById(int movieShowId) {
		Optional<MovieShow> movie = movieShowRepository.findById(movieShowId);
		if (movie.isPresent())
			return movie.get();
		else
			throw new DataNotFoundException("the movie show with the given id doesnot present");

	}

	@Override
	public List<MovieShow> findByMovieMovieNameAndTheatreAddressCity(String movieName, String city) {

		return movieShowRepository.findByMovieMovieNameAndTheatreAddressCity(movieName, city);
	}

	@Override
	public MovieShow saveMovieShow(MovieShow movieShow) {
		return movieShowRepository.save(movieShow);
	}

	@Override
	public List<MovieShow> getAllMovieShows() {
		return movieShowRepository.findAll();
	}

	@Override
	public List<MovieShow> searchMovieShows(String movieName, String screen, String city) {
		return movieShowRepository.findMovieShows(movieName, screen, city);
	}

	@Override
	public List<MovieShow> getAllShowsByTheatreId(int theatreId) {
		List<MovieShow> ms = movieShowRepository.findAllByTheatre_TheatreId(theatreId);
		return ms;
	}

	@Override
	public Movie getMovieByName(String movieName) {
		return movieRepository.findByMovieName(movieName);
	}

	@Override
	public List<MovieShow> getMovieShowsByMovieAndTheatre(int movieId, List<Theatre> theatres) {
		if (theatres == null || theatres.isEmpty()) {
			throw new DataNotFoundException("No theatres found for the given movie");
		}

		List<MovieShow> movieShows = movieShowRepository.findMovieShowsByMovieAndTheatre(movieId, theatres);

		if (movieShows == null || movieShows.isEmpty()) {
			throw new DataNotFoundException("No movie shows found for the given movie and theatres");
		}

		return movieShows;
	}

}

