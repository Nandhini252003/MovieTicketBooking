package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.ITheatreDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.repository.TheatreRepository;

@Repository
public class TheatreDao implements ITheatreDao {
	@Autowired
	private TheatreRepository theatreRepository;

	@Override
	public List<Theatre> getAllTheatres() {

		return theatreRepository.findAll();

	}

	@Override
	public Theatre theatreDetailsByName(String theatreName) {
		Optional<Theatre> optional = theatreRepository.findTheatreByTheatreName(theatreName);
		if (optional.isEmpty()) {
			throw new DataNotFoundException("Theatre not found for given name");
		}
		return optional.get();
	}

	@Override
	public Theatre getTheatreById(int theatreid) {
		Optional<Theatre> optional = theatreRepository.findById(theatreid);
		if (optional.isEmpty()) {
			throw new DataNotFoundException("Theatre not found for given id:" + theatreid);
		}
		return optional.get();
	}

	@Override
	public List<Theatre> getTheatreByCity(String city) {
		return theatreRepository.findByAddressCity(city);
	}


	@Override
	public Theatre saveTheatre(Theatre theatre) {
		return theatreRepository.save(theatre);
	}


	@Override
	public Theatre findById(int theatreId) {
		Optional<Theatre> optionalTheatre = theatreRepository.findById(theatreId);
		if (optionalTheatre.isPresent()) {
			Theatre theatre = optionalTheatre.get();
			return theatre;
		} else {
			throw new DataNotFoundException("Theatre with id " + theatreId + " not found");
		}

	}

	@Override
	public List<Theatre> findByAddressCountry(String country) {
		return theatreRepository.findByAddressCountry(country);
	}

	@Override
	public Theatre getTheatreByName(String name) {
		Optional<Theatre> optionalTheatre = theatreRepository.findByTheatreName(name);
		if (optionalTheatre.isPresent()) {
			return optionalTheatre.get();

		} else {
			throw new DataNotFoundException("Theatre with name:" + name + " not found");
		}
	}

	@Override
	public List<Theatre> getTheatresByCityAndScreen(int addressId, String screenType) {
		System.out.println("Fetching theatres for addressId: " + addressId + " and screenType: " + screenType);
		List<Theatre> theatres = theatreRepository.findByAddress_AddressIdAndScreen(addressId, screenType);
		if (theatres.isEmpty()) {
			System.out.println("No theatres found for addressId: " + addressId + " and screenType: " + screenType);
		}
		return theatres;
	}

	@Override
	public Theatre findTheatreById(int theatreId) {
		return theatreRepository.findById(theatreId).get();
	}

	@Override
	public Theatre save(Theatre theatre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Theatre> getTheatreWithMaxCapacity() {
		 return theatreRepository.findAll()
	                .stream()
	                .max((theatre1, theatre2) -> Integer.compare(theatre1.getCapacity(), theatre2.getCapacity()));
	    
	}

	@Override
	public List<String> findTheatresInAlphabeticalOrder() {
		return theatreRepository.findAll()
                .stream()
                .map(theatre -> theatre.getTheatreName())
                .filter(name -> name != null && !name.trim().isEmpty())  // Filter out null or empty names
                .sorted() // Sort alphabetically
                .collect(Collectors.toList());
	}

	@Override
	public List<Theatre> getTheatresByCapacityRange(int minCapacity, int maxCapacity) {
		return theatreRepository.findByCapacityBetween(minCapacity, maxCapacity);

	}

	@Override
	public List<Theatre> getTheatresByScreenType(String screenType) {
		 return theatreRepository.findByScreen(screenType);
	}
	public boolean findTheatreId(int theatre_id) {
		return theatreRepository.existsById(theatre_id);
	}
	


}
