package com.book.book_my_show.service.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IMovieDao;
import com.book.book_my_show.dao.IMovieShowDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Movie;
import com.book.book_my_show.dao.IAddressDao;
import com.book.book_my_show.model.entity.MovieShow;
import com.book.book_my_show.model.responseDto.MovieShowResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.service.IMovieShowService;
import com.book.book_my_show.dao.ITheatreDao;
import com.book.book_my_show.model.entity.Address;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.requestDto.MovieShowRequestDto;

@Service
public class MovieShowService implements IMovieShowService {
	@Autowired
	private IMovieShowDao iMovieShowDao;

	@Autowired
	private ITheatreDao iTheatreDao;
	@Autowired
	private IMovieDao iMovieDao;
	@Autowired
	private IAddressDao iAddressDao;

	@Override
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowByMovieName(String movieName) {

		List<MovieShow> movieShows = iMovieShowDao.getMovieShowByMovieName(movieName);
		List<MovieShowResponseDto> movieShowResponseDto = movieShows.stream()
				.map(movieShow -> new MovieShowResponseDto(movieShow.getShowId(), movieShow.getMovie().getMovieId(),
						movieShow.getTheatre().getTheatreId(), movieShow.getShowDateTime()))
				.collect(Collectors.toList());

		if (!movieShowResponseDto.isEmpty()) {
			// Initialize ResponseStructure and set the data
			ResponseStructure<List<MovieShowResponseDto>> response = new ResponseStructure<>();
			response.setData(movieShowResponseDto);
			response.setMessage("MovieShows found");
			response.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<>(response, HttpStatus.FOUND);
		} else {
			throw new DataNotFoundException("MovieShow doesn't Exist for movie name: " + movieName);
		}
	}

	@Override
	public ResponseEntity<ResponseStructure<MovieShowResponseDto>> getMovieShowById(int movieShowId) {
		MovieShow movieShow = iMovieShowDao.movieShowById(movieShowId);
		MovieShowResponseDto ca = new MovieShowResponseDto();
		ca.setShowId(movieShow.getShowId());
		ca.setMovieId(movieShow.getMovie().getMovieId());
		ca.setTheatreId(movieShow.getTheatre().getTheatreId());
		ca.setShowDateTime(movieShow.getShowDateTime());
		ResponseStructure<MovieShowResponseDto> response = new ResponseStructure<>();
		response.setMessage("Success");
		response.setStatusCode(HttpStatus.FOUND.value());
		response.setData(ca);

		return new ResponseEntity<ResponseStructure<MovieShowResponseDto>>(response, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowsByMovieNameAndCity(
			String movieName, String city) {

		List<MovieShow> movieShows = iMovieShowDao.findByMovieMovieNameAndTheatreAddressCity(movieName, city);
		ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
		if (movieShows.isEmpty()) {
			responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
			responseStructure.setMessage("No movie shows found for the given movie name and city.");
			responseStructure.setData(null);
			return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
		}
		List<MovieShowResponseDto> dtos = movieShows.stream().map(data -> {
			MovieShowResponseDto dto = new MovieShowResponseDto();
			dto.setMovieId(data.getMovie().getMovieId());
			dto.setShowDateTime(data.getShowDateTime());
			dto.setShowId(data.getShowId());
			dto.setTheatreId(data.getTheatre().getTheatreId());
			return dto;
		}).collect(Collectors.toList());

		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Movie shows found.");
		responseStructure.setData(dtos);
		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getAllMovieShows() {

		List<MovieShow> movieShows = iMovieShowDao.getAllMovieShows();

		List<MovieShowResponseDto> movieShowResponseDtos = movieShows.stream()
				.map(movieShow -> new MovieShowResponseDto(movieShow.getShowId(), movieShow.getMovie().getMovieId(),
						movieShow.getTheatre().getTheatreId(), movieShow.getShowDateTime()))
				.collect(Collectors.toList());
		ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Success");
		responseStructure.setData(movieShowResponseDtos);

		return new ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>>(responseStructure, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> searchMovieShows(String movieName,
			String screen, String city) {
		List<MovieShow> movieShows = iMovieShowDao.searchMovieShows(movieName, screen, city);

		List<MovieShowResponseDto> movieShowResponseDtos = movieShows.stream()
				.map(movieShow -> new MovieShowResponseDto(movieShow.getShowId(), movieShow.getMovie().getMovieId(),
						movieShow.getTheatre().getTheatreId(), movieShow.getShowDateTime()))
				.collect(Collectors.toList());

		ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Success");
		responseStructure.setData(movieShowResponseDtos);

		return new ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>>(responseStructure, HttpStatus.FOUND);

	}

	@Override
	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> getMovieShowsByTheatreName(
			String theatrename) {
		Theatre theatre = iTheatreDao.getTheatreByName(theatrename);
		int theatreId = theatre.getTheatreId();
		List<MovieShow> movieShows = iMovieShowDao.getAllShowsByTheatreId(theatreId);
		if (movieShows == null) {
			throw new DataNotFoundException("no movie shows exist for the given theatre name");
		}

		List<MovieShowResponseDto> movieShowResponseDtos = movieShows.stream()
				.map(movieShow -> new MovieShowResponseDto(movieShow.getShowId(), movieShow.getMovie().getMovieId(),
						movieShow.getTheatre().getTheatreId(), movieShow.getShowDateTime()))
				.collect(Collectors.toList());
		ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("Fetched all movie shows successfully");
		responseStructure.setData(movieShowResponseDtos);
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		return new ResponseEntity<>(responseStructure, HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>> findShowByMovieNameScreenTypeCity(
			String movieName, String screenType, String city) {

		Movie movie = iMovieShowDao.getMovieByName(movieName);
		if (movie == null) {
			throw new DataNotFoundException("Movie not found for the given name");
		}

		List<Address> addresses = iAddressDao.getAddressesByCity(city); // Returns a list of addresses
		if (addresses == null || addresses.isEmpty()) {
			throw new DataNotFoundException("No theatres found in the given city");
		}
		System.out.println("Addresses for city " + city + ": " + addresses);

		List<Theatre> theatres = new ArrayList<>();
		for (Address address : addresses) {
			List<Theatre> theatreList = iTheatreDao.getTheatresByCityAndScreen(address.getAddressId(), screenType);
			System.out.println("Theatres for addressId " + address.getAddressId() + " and screenType " + screenType
					+ ": " + theatreList);
			if (theatreList != null && !theatreList.isEmpty()) {
				theatres.addAll(theatreList);
			}
		}

		if (theatres.isEmpty()) {
			throw new DataNotFoundException("No theatres with the given screen type found in the city");
		}

		List<MovieShow> movieShows = iMovieShowDao.getMovieShowsByMovieAndTheatre(movie.getMovieId(), theatres);
		if (movieShows == null || movieShows.isEmpty()) {
			throw new DataNotFoundException("No movie shows found for the given movie, screen type, and city");
		}

		List<MovieShowResponseDto> movieShowResponseDtos = movieShows.stream()
				.map(movieShow -> new MovieShowResponseDto(movieShow.getShowId(), movieShow.getMovie().getMovieId(),
						movieShow.getTheatre().getTheatreId(), movieShow.getShowDateTime()))
				.collect(Collectors.toList());

		ResponseStructure<List<MovieShowResponseDto>> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("Fetched all movie shows successfully");
		responseStructure.setData(movieShowResponseDtos);
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		return new ResponseEntity<ResponseStructure<List<MovieShowResponseDto>>>(responseStructure, HttpStatus.FOUND);
	}

	@Override
	public ResponseEntity<ResponseStructure<MovieShowResponseDto>> saveMovieShow(
			MovieShowRequestDto movieShowRequestDto) {
		Movie movie = iMovieDao.getMovieById(movieShowRequestDto.getMovieId());
		if (movie == null) {
			throw new DataNotFoundException("Movie not found with the given ID");
		}

		Theatre theatre = iTheatreDao.findTheatreById(movieShowRequestDto.getTheatreId());
		if (theatre == null) {
			throw new DataNotFoundException("Theatre with ID " + movieShowRequestDto.getTheatreId() + " not found");
		}

		MovieShow movieShow = new MovieShow();
		movieShow.setMovie(movie); // Set the movie
		movieShow.setShowDateTime(movieShowRequestDto.getShowDateTime());

	
		movieShow.setTheatre(theatre);

	
		MovieShow savedMovieShow = iMovieShowDao.saveMovieShow(movieShow);

		MovieShowResponseDto savedMovieShowResponseDto = new MovieShowResponseDto();
		savedMovieShowResponseDto.setShowId(savedMovieShow.getShowId());
		savedMovieShowResponseDto.setMovieId(savedMovieShow.getMovie().getMovieId());
		savedMovieShowResponseDto.setShowDateTime(savedMovieShow.getShowDateTime());

		if (savedMovieShow.getTheatre() != null) {
			savedMovieShowResponseDto.setTheatreId(savedMovieShow.getTheatre().getTheatreId());
		}

		// Wrap the response in a ResponseStructure
		ResponseStructure<MovieShowResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("Movie Show added successfully");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(savedMovieShowResponseDto);

		return new ResponseEntity<>(responseStructure, HttpStatus.CREATED);
	}

}
