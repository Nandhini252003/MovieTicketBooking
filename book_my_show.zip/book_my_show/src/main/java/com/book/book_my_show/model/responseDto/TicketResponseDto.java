package com.book.book_my_show.model.responseDto;

import java.time.LocalDateTime;

public class TicketResponseDto {
	private int ticketId;
	private int amount;
	private LocalDateTime purchaseDate;
	private int seatId;
	private int movieShowId;
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public LocalDateTime getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDateTime purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getSeatId() {
		return seatId;
	}
	public void setSeatId(int seat) {
		this.seatId = seat;
	}
	public int getMovieShowId() {
		return movieShowId;
	}
	public void setMovieShowId(int movieShow) {
		this.movieShowId = movieShow;
	}
	public TicketResponseDto(int ticketId, int amount, LocalDateTime purchaseDate, int seat, int movieShow) {
		super();
		this.ticketId = ticketId;
		this.amount = amount;
		this.purchaseDate = purchaseDate;
		this.seatId = seat;
		this.movieShowId = movieShow;
	}
	public TicketResponseDto() {
	}
	
}
