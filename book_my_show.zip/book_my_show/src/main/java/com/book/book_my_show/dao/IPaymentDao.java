package com.book.book_my_show.dao;

import java.util.List;
import com.book.book_my_show.model.entity.Payment;

public interface IPaymentDao {
//	public Payment addPayment(Payment payment); 
	List<Payment> getPaymentDetailsByUserId(int userId);
	public List<Payment> getAllPayments();
	public Payment addPayment(Payment payment);
	public Payment getPaymentById(int paymentId);
	public List<Payment> getPaymentsByStatus(String paymentStatus);
	public List<Payment> getPaymentsByUserId(int userId);
}
