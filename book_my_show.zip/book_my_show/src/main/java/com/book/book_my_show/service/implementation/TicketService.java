package com.book.book_my_show.service.implementation;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.book.book_my_show.dao.IMovieShowDao;
import com.book.book_my_show.dao.ISeatDao;
import com.book.book_my_show.dao.ITicketDao;
import com.book.book_my_show.exception.DataAlreadyExistsException;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.MovieShow;
import com.book.book_my_show.model.entity.Seat;
import com.book.book_my_show.model.entity.Theatre;
import com.book.book_my_show.model.entity.Ticket;
import com.book.book_my_show.model.requestDto.TicketRequestDto;
import com.book.book_my_show.model.responseDto.MovieShowResponseDto;
import com.book.book_my_show.model.responseDto.ResponseStructure;
import com.book.book_my_show.model.responseDto.SeatResponseDto;
import com.book.book_my_show.model.responseDto.TheatreResponseDto;
import com.book.book_my_show.model.responseDto.TicketResponseDto;
import com.book.book_my_show.repository.TheatreRepository;
import com.book.book_my_show.service.ITicketService;

@Service
public class TicketService implements ITicketService {
	@Autowired
	private ITicketDao iTicketDao;
	@Autowired
	private IMovieShowDao iMovieShowDao;
	@Autowired
	private ISeatDao iSeatDao;

	@Override
	public List<TicketResponseDto> getAllTickets() {
		List<Ticket> tickets = iTicketDao.getAllTickets();
		List<TicketResponseDto> ticketResponseDtos = new ArrayList<>();
		for (Ticket ticket : tickets) {
			TicketResponseDto ticketResponseDto = new TicketResponseDto();
			ticketResponseDto.setTicketId(ticket.getTicketId());
			ticketResponseDto.setAmount(ticket.getAmount());
			ticketResponseDto.setPurchaseDate(ticket.getPurchaseDate());
			ticketResponseDto.setSeatId(ticket.getSeat().getSeatId());
			ticketResponseDto.setMovieShowId(ticket.getMovieShow().getShowId());
			ticketResponseDtos.add(ticketResponseDto);
		}
		return ticketResponseDtos;
	}

	@Override
	public ResponseEntity<ResponseStructure<TicketResponseDto>> addTicket(TicketRequestDto ticketRequestDto) {
		Ticket ticket = new Ticket();
		ticket.setPurchaseDate(LocalDateTime.now());
		ticket.setAmount(ticketRequestDto.getAmount());

		MovieShow movieShow = iMovieShowDao.movieShowById(ticketRequestDto.getMovieShowId());
		if (movieShow == null) {
	        throw new DataNotFoundException("Movie Show not found with the given ID");
	        
	    }
		
		ticket.setMovieShow(movieShow);
		
		
		Seat seat = iSeatDao.seatById(ticketRequestDto.getSeatId());
	    if (seat == null) {
	        throw new DataNotFoundException("Seat not found with the given ID");
	    }
	    Ticket existingTicket = iTicketDao.findTicketBySeatAndMovieShow(seat.getSeatId(), movieShow.getShowId());
	    if (existingTicket != null) {
	        throw new DataAlreadyExistsException("Seat is already taken for this Movie Show");
	    }
		ticket.setSeat(seat);

		Ticket saved = iTicketDao.addNewTicket(ticket);

		TicketResponseDto ticketResponseDto = new TicketResponseDto();
		ticketResponseDto.setTicketId(saved.getTicketId());
		ticketResponseDto.setAmount(saved.getAmount());
		ticketResponseDto.setPurchaseDate(saved.getPurchaseDate());

		MovieShowResponseDto Responsedto = new MovieShowResponseDto();
		if (saved.getMovieShow() != null) {
			Responsedto.setShowId(saved.getMovieShow().getShowId());

		}
		ticketResponseDto.setMovieShowId(saved.getMovieShow().getShowId());

		SeatResponseDto seatResponsedto = new SeatResponseDto();
		if (saved.getSeat() != null) {
			seatResponsedto.setSeatId(saved.getSeat().getSeatId());

		}
		ticketResponseDto.setSeatId(saved.getSeat().getSeatId());

		ResponseStructure<TicketResponseDto> response = new ResponseStructure<>();
		response.setStatusCode(HttpStatus.CREATED.value());
		response.setMessage("Ticket added");
		response.setData(ticketResponseDto);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	public ResponseEntity<ResponseStructure<TicketResponseDto>> getTicketById(int ticketId) {
		
		Ticket ticket = iTicketDao.getTicketById(ticketId);
		TicketResponseDto addressResponseDto = new TicketResponseDto();
		addressResponseDto.setTicketId(ticket.getTicketId());
		addressResponseDto.setSeatId(ticket.getSeat().getSeatId());
		addressResponseDto.setAmount(ticket.getAmount());
		addressResponseDto.setPurchaseDate(ticket.getPurchaseDate());
		
		addressResponseDto.setMovieShowId(ticket.getMovieShow().getShowId());
//		addressResponseDto.setAddressLine(ticket.getAddressLine());
		
		ResponseStructure<TicketResponseDto> responseStructure = new ResponseStructure<>();
		responseStructure.setMessage("success");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(addressResponseDto);
		return new ResponseEntity<ResponseStructure<TicketResponseDto>>(responseStructure, HttpStatus.FOUND);
	}

	@Autowired
    private TheatreRepository theatreRepository;
	
	public ResponseEntity<ResponseStructure<TheatreResponseDto>> getTheatreWithMaxTicketsSold() {
        
        List<Theatre> allTheatres = theatreRepository.findAll();

        int maxTicketCount = 0;
        Theatre maxTheatre = null;

        
        for (Theatre theatre : allTheatres) {
            
            int ticketCount = iTicketDao.countTicketsByTheatreId(theatre.getTheatreId());

            if (ticketCount > maxTicketCount) {
                maxTicketCount = ticketCount;
                maxTheatre = theatre;
            }
        }

       
        ResponseStructure<TheatreResponseDto> responseStructure = new ResponseStructure<>();

        if (maxTheatre != null) {
            
            TheatreResponseDto theatreResponseDto = new TheatreResponseDto(
                    maxTheatre.getTheatreId(),
                    maxTheatre.getAddress().getAddressId(), 
                    maxTheatre.getTheatreName(),
                    maxTheatre.getCapacity(),
                    maxTheatre.getScreen()
            );
            responseStructure.setMessage("theatre details with maximun number of tickets sold");
            responseStructure.setStatusCode(HttpStatus.OK.value());
            responseStructure.setData(theatreResponseDto);
            return new ResponseEntity<>(responseStructure, HttpStatus.FOUND);
        } else {
            responseStructure.setMessage("No theatres found or no tickets sold");
            responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
            responseStructure.setData(null);
            return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
        }


    }
}
