package com.book.book_my_show.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.book.book_my_show.model.entity.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer>{
		Movie findByMovieName(String movieName);
	    List<Movie> findByMovieNameStartingWithIgnoreCase(String prefix);
	    List<Movie> findByTicketBasePriceLessThan(int price);
	    List<Movie> findByMovieNameContaining(String name);
	    List<Movie> findByTicketBasePriceBetween(int minPrice, int maxPrice);
	
	@Query("SELECT m FROM Movie m WHERE m.movieId IN :movieIds")
	List<Movie> findMoviesByIds(List<Integer> movieIds);
	
}
