package com.book.book_my_show.dao.implementation;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.book.book_my_show.dao.IPaymentDao;
import com.book.book_my_show.exception.DataNotFoundException;
import com.book.book_my_show.model.entity.Payment;
import com.book.book_my_show.model.responseDto.PaymentResponseDto;
import com.book.book_my_show.repository.PaymentRepository;

@Repository
public class PaymentDao implements IPaymentDao {
	@Autowired
	private PaymentRepository paymentRepository;

	@Override
	public Payment addPayment(Payment payment) {
		return paymentRepository.save(payment);
	}

	@Override
	public Payment getPaymentById(int paymentId) {
		Optional<Payment> payment = paymentRepository.findById(paymentId);
		if (payment.isPresent())
			return payment.get();
		else
			throw new DataNotFoundException("Data is Not present");
	}

	@Override
	public List<Payment> getPaymentsByStatus(String paymentStatus) {

		return paymentRepository.findByStatus(paymentStatus);
	}

	@Override
	public List<Payment> getPaymentsByUserId(int userId) {
		List<Payment> payment = paymentRepository.findByUser_UserId(userId);
		if (payment != null)
			return payment;
		else
			throw new DataNotFoundException("No payments found for the given userId");
	}

	@Override
	public List<Payment> getAllPayments() {
		return paymentRepository.findAll();
	}

	@Override
	public List<Payment> getPaymentDetailsByUserId(int userId) {
		return paymentRepository.findByUser_UserId(userId);

	}

}
